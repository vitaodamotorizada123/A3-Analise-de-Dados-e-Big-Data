"""Camada de análise do caso Conecta Cultura: resultados (fonte única dos números) e figuras."""
