"""Resultados da análise do caso Conecta Cultura (A3): a fonte única de números.

Lê os CSVs tratados que o ETL grava (UTF-8, ";", ponto decimal) e calcula todos os indicadores usados no
resumo acadêmico, no documento técnico, no roteiro do vídeo e no painel do Power BI. Os textos devem
citar apenas valores de `resultados.json`.

Regras dos indicadores (valem para qualquer recorte, todos calculados por `metricas`):
- razões saem dos totais do recorte, nunca da média de razões linha a linha;
- denominador zero devolve `None`; CPC e custo por pedido só existem com investimento maior que zero;
- `custo_por_pedido` é um custo MISTO: investimento do recorte dividido por TODOS os pedidos atribuídos do
  recorte, inclusive os de canais sem custo direto (e-mail, orgânico, direto). Só no recorte de um canal pago
  ele é o custo do pedido daquele canal. `custo_por_pedido_pago` divide o mesmo investimento só pelos pedidos
  de canais pagos (natureza_midia "paga" ou "parceria_paga") e é o que se compara entre canais, mensagens e fases;
- no JSON valores em reais têm 2 casas e razões/participações 6 (os textos formatam); nunca há NaN.

Uso: python -m analise.resultados --dados build/03_dados_tratados --saida build/resultados.json
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
DADOS_PADRAO = RAIZ / "build" / "03_dados_tratados"
SAIDA_PADRAO = RAIZ / "build" / "resultados.json"

FASE_POR_OBJETIVO = {"reconhecimento": "Descoberta", "vendas": "Convite"}
FASES = ["Descoberta", "Convite"]
SEMANAS = range(9)  # semana_antes_evento: 0 (dia do evento) a 8
NATUREZAS_PAGAS = ("paga", "parceria_paga")

# Cenário de alocação ilustrativo (decisão do projeto).
CENARIO_TOTAL = 108000.0
CENARIO_RESERVA = 12000.0  # fica fora dos 108.000
CENARIO_TESTE_AB = 10800.0  # 10% do total
CENARIO_PASSO = 100  # os valores por canal são múltiplos de R$ 100

# Chave do resultado -> coluna da fato (somas de cada recorte), na ordem em que aparecem no JSON.
SOMAS = {
    "investimento": "investimento",
    "impressoes": "impressoes",
    "cliques": "cliques",
    "sessoes": "sessoes",
    "checkouts": "checkouts_iniciados",
    "pedidos": "pedidos_confirmados",
    "ingressos": "ingressos_vendidos",
    "receita_bruta": "receita_bruta",
    "descontos": "descontos",
    "receita_liquida": "receita_liquida",
    "mensagens": "quantidade_interacoes",
}
SOMAS_EM_REAIS = {"investimento", "receita_bruta", "descontos", "receita_liquida"}

# Chaves cujo valor decimal é dinheiro (2 casas no JSON); os demais decimais são razões (6 casas).
CHAVES_EM_REAIS = SOMAS_EM_REAIS | {
    "orcamento_planejado", "orcamento_planejado_total", "valor", "total", "reserva", "teste_ab",
}

COLUNAS_ID = ["id_registro", "data", "id_campanha", "id_canal", "id_peca", "id_regiao", "id_segmento", "id_evento"]


# --- leitura ---------------------------------------------------------------------------------------

def _ler(pasta: Path, nome: str, **kwargs) -> pd.DataFrame:
    """Lê um CSV tratado. IDs e datas sempre como texto."""
    return pd.read_csv(Path(pasta) / nome, sep=";", encoding="utf-8", keep_default_na=False, **kwargs)


def _ler_dim(pasta: Path, nome: str) -> pd.DataFrame:
    return _ler(pasta, f"{nome}.csv", dtype=str)


def _montar_base(pasta: Path) -> tuple[pd.DataFrame, dict[str, pd.DataFrame]]:
    """Fato tratada com as colunas descritivas das dimensões (fase, canal, edição, região, peça, mês)."""
    dims = {
        nome: _ler_dim(pasta, nome)
        for nome in ("Dim_Calendario", "Dim_Campanha", "Dim_Canal", "Dim_Evento", "Dim_Peca_Publicitaria", "Dim_Regiao")
    }
    dims["Dim_Campanha"]["orcamento_planejado"] = dims["Dim_Campanha"]["orcamento_planejado"].astype(float)
    dims["Dim_Campanha"]["fase"] = dims["Dim_Campanha"]["objetivo"].map(FASE_POR_OBJETIVO)
    dims["Dim_Evento"]["capacidade"] = dims["Dim_Evento"]["capacidade"].astype(int)
    if dims["Dim_Campanha"]["fase"].isna().any():
        raise ValueError("Dim_Campanha tem objetivo sem fase definida (esperado: reconhecimento ou vendas)")

    fato = _ler(pasta, "Fato_Desempenho_Campanha_tratada.csv", dtype={c: str for c in COLUNAS_ID})
    base = fato
    unioes = [
        ("Dim_Calendario", "data", ["data", "ano_mes"]),
        ("Dim_Campanha", "id_campanha", ["id_campanha", "fase"]),
        ("Dim_Canal", "id_canal", ["id_canal", "nome_canal", "natureza_midia"]),
        ("Dim_Evento", "id_evento", ["id_evento", "nome_edicao", "cidade_evento", "data_evento", "capacidade"]),
        ("Dim_Peca_Publicitaria", "id_peca", ["id_peca", "mensagem"]),
        ("Dim_Regiao", "id_regiao", ["id_regiao", "municipio", "uf", "regiao_pais"]),
    ]
    for nome, chave, colunas in unioes:
        base = base.merge(dims[nome][colunas], on=chave, how="left", validate="many_to_one")
        if base[colunas[1]].isna().any():
            raise ValueError(f"a fato tem {chave} sem correspondência em {nome}")
    if len(base) != len(fato):
        raise ValueError("a junção com as dimensões mudou o número de linhas da fato")
    return base, dims


# --- indicadores de um recorte -------------------------------------------------------------------------

def _razao(numerador, denominador):
    """Razão dos totais; denominador zero devolve None."""
    return None if not denominador else numerador / denominador


def metricas(df: pd.DataFrame) -> dict:
    """Conjunto de indicadores de qualquer recorte da fato (a única conta de indicadores do projeto).

    Exige a coluna `natureza_midia` (vem de Dim_Canal). Duas medidas de custo por pedido:
    - `custo_por_pedido` (misto): investimento ÷ todos os pedidos atribuídos do recorte, inclusive de canais
      sem custo direto; é o custo de mídia diluído em todas as vendas atribuídas;
    - `custo_por_pedido_pago`: investimento ÷ pedidos dos canais pagos ("paga" e "parceria_paga") do recorte;
      None se esses pedidos forem zero ou se não houver investimento.
    """
    s = {}
    for chave, coluna in SOMAS.items():
        total = df[coluna].sum()
        s[chave] = float(total) if chave in SOMAS_EM_REAIS else int(total)
    investimento = s["investimento"]
    com_custo = investimento > 0  # canais sem investimento não têm CPC nem custo por pedido
    pedidos_pagos = int(df.loc[df["natureza_midia"].isin(NATUREZAS_PAGAS), SOMAS["pedidos"]].sum())
    return {
        **s,
        "ctr": _razao(s["cliques"], s["impressoes"]),
        "cpc": _razao(investimento, s["cliques"]) if com_custo else None,
        "taxa_checkout": _razao(s["checkouts"], s["sessoes"]),
        "conversao": _razao(s["pedidos"], s["sessoes"]),
        "conclusao_checkout": _razao(s["pedidos"], s["checkouts"]),
        "custo_por_pedido": _razao(investimento, s["pedidos"]) if com_custo else None,
        "custo_por_pedido_pago": _razao(investimento, pedidos_pagos) if com_custo else None,
        "receita_por_real": _razao(s["receita_liquida"], investimento),
        "ingressos_por_pedido": _razao(s["ingressos"], s["pedidos"]),
        "ticket_medio": _razao(s["receita_liquida"], s["pedidos"]),
    }


def _por_grupo(base: pd.DataFrame, coluna: str, ordem: list[str]) -> dict[str, dict]:
    """`metricas` de cada valor de `coluna`, na ordem dada (valor sem linhas fica com zeros e None)."""
    grupos = dict(tuple(base.groupby(coluna, sort=False)))
    vazio = base.iloc[0:0]
    return {chave: metricas(grupos.get(chave, vazio)) for chave in ordem}


# --- blocos do resultado -----------------------------------------------------------------------------

def _totais(base: pd.DataFrame, dims: dict[str, pd.DataFrame]) -> dict:
    m = metricas(base)
    capacidade = int(dims["Dim_Evento"]["capacidade"].sum())  # uma vez por edição
    orcamento = float(dims["Dim_Campanha"]["orcamento_planejado"].sum())  # uma vez por campanha
    return {
        **m,
        "capacidade_total": capacidade,
        "ocupacao": _razao(m["ingressos"], capacidade),
        "orcamento_planejado_total": orcamento,
        "execucao_orcamento": _razao(m["investimento"], orcamento),
    }


def _por_canal(base: pd.DataFrame, dims: dict, totais: dict) -> dict:
    canais = dims["Dim_Canal"]
    natureza = dict(zip(canais["nome_canal"], canais["natureza_midia"]))
    por_canal = _por_grupo(base, "nome_canal", list(canais["nome_canal"]))
    return {
        nome: {**m, "natureza_midia": natureza[nome], "share_pedidos": _razao(m["pedidos"], totais["pedidos"])}
        for nome, m in por_canal.items()
    }


def _por_fase(base: pd.DataFrame, totais: dict) -> dict:
    return {
        fase: {
            **m,
            "share_ingressos": _razao(m["ingressos"], totais["ingressos"]),
            "share_investimento": _razao(m["investimento"], totais["investimento"]),
            "share_pedidos": _razao(m["pedidos"], totais["pedidos"]),
        }
        for fase, m in _por_grupo(base, "fase", FASES).items()
    }


def _por_canal_fase(base: pd.DataFrame, dims: dict) -> dict:
    canais = list(dims["Dim_Canal"]["nome_canal"])
    return {fase: _por_grupo(base[base["fase"] == fase], "nome_canal", canais) for fase in FASES}


def _fase_predominante(recorte: pd.DataFrame):
    """Fase com mais ingressos no recorte (None se o recorte não vendeu nada)."""
    soma = recorte.groupby("fase")["ingressos_vendidos"].sum()
    return None if soma.empty or soma.max() == 0 else str(soma.idxmax())


def _por_semana(base: pd.DataFrame, totais: dict) -> dict:
    semanas = {}
    for semana in SEMANAS:
        recorte = base[base["semana_antes_evento"] == semana]
        m = metricas(recorte)
        semanas[str(semana)] = {
            **m,
            "fase": _fase_predominante(recorte),
            "share_ingressos": _razao(m["ingressos"], totais["ingressos"]),
        }
    return semanas


def _por_edicao(base: pd.DataFrame, dims: dict) -> dict:
    eventos = dims["Dim_Evento"].sort_values("data_evento")
    por_edicao = _por_grupo(base, "nome_edicao", list(eventos["nome_edicao"]))
    saida = {}
    for _, e in eventos.iterrows():
        m = por_edicao[e["nome_edicao"]]
        capacidade = int(e["capacidade"])
        saida[e["nome_edicao"]] = {
            **m,
            "cidade_evento": e["cidade_evento"],
            "data_evento": e["data_evento"],
            "capacidade": capacidade,
            "ocupacao": _razao(m["ingressos"], capacidade),
        }
    return saida


def _por_regiao(base: pd.DataFrame, dims: dict) -> dict:
    regioes = dims["Dim_Regiao"]
    por_regiao = _por_grupo(base, "municipio", list(regioes["municipio"]))
    return {
        r["municipio"]: {**por_regiao[r["municipio"]], "uf": r["uf"], "regiao_pais": r["regiao_pais"]}
        for _, r in regioes.iterrows()
    }


def _por_mensagem_peca(base: pd.DataFrame, dims: dict) -> dict:
    mensagens = list(dict.fromkeys(dims["Dim_Peca_Publicitaria"]["mensagem"]))  # ordem de aparição
    return _por_grupo(base, "mensagem", mensagens)


def _mensal(base: pd.DataFrame) -> list[dict]:
    meses = []
    for ano_mes, recorte in base.groupby("ano_mes", sort=True):
        m = metricas(recorte)
        meses.append({
            "ano_mes": str(ano_mes),
            "investimento": m["investimento"],
            "ingressos": m["ingressos"],
            "pedidos": m["pedidos"],
            "receita_liquida": m["receita_liquida"],
        })
    return meses


def _orcamento_campanhas(base: pd.DataFrame, dims: dict) -> list[dict]:
    investido = base.groupby("id_campanha")["investimento"].sum()
    linhas = []
    for _, c in dims["Dim_Campanha"].iterrows():
        investimento = float(investido.get(c["id_campanha"], 0.0))
        linhas.append({
            "id_campanha": c["id_campanha"],
            "nome": c["nome"],
            "orcamento_planejado": float(c["orcamento_planejado"]),
            "investimento": investimento,
            "execucao": _razao(investimento, float(c["orcamento_planejado"])),
        })
    return linhas


def _temas_por_fase(pasta: Path, base: pd.DataFrame) -> dict:
    """Mensagens do público por tema, tipo e fase. As mensagens são contadas, nunca somadas como medida da
    fato: a fato só informa a fase (id_registro -> id_campanha -> objetivo)."""
    inter = _ler(pasta, "Interacoes_Classificadas.csv", dtype=str)
    fases = base[["id_registro", "fase"]]
    inter = inter.merge(fases, on="id_registro", how="left", validate="many_to_one")
    if inter["fase"].isna().any():
        raise ValueError("há mensagens cujo id_registro não existe na fato")

    duvidas = inter[inter["tipo"] == "dúvida"]
    contagem = duvidas["tema"].value_counts()
    temas = sorted(contagem.index, key=lambda t: (-int(contagem[t]), t))  # mais citado primeiro
    total = int(len(duvidas))
    por_tema = {t: int(contagem[t]) for t in temas}
    por_fase, share_por_fase = {}, {}
    for fase in FASES:
        c = duvidas[duvidas["fase"] == fase]["tema"].value_counts()
        por_fase[fase] = {t: int(c.get(t, 0)) for t in temas}
        n_fase = sum(por_fase[fase].values())
        share_por_fase[fase] = {t: _razao(n, n_fase) for t, n in por_fase[fase].items()}
    tipos = inter["tipo"].value_counts()
    cruzado = inter.groupby(["tema", "tipo"]).size()
    return {
        "duvidas_por_tema": por_tema,
        "duvidas_total": total,
        "share_por_tema": {t: _razao(n, total) for t, n in por_tema.items()},
        "por_fase": por_fase,
        "duvidas_por_fase": {fase: sum(v.values()) for fase, v in por_fase.items()},
        "share_por_fase": share_por_fase,
        "mensagens_total": int(len(inter)),
        "por_tipo": {t: int(tipos[t]) for t in tipos.index},
        "por_tema_tipo": {
            t: {tipo: int(n) for (tema, tipo), n in cruzado.items() if tema == t}
            for t in sorted(inter["tema"].unique())
        },
    }


# --- cenário de alocação ---------------------------------------------------------------------------------

def distribuir_inteiros(pesos: list[float], total: int) -> list[int]:
    """Divide `total` (inteiro) em partes inteiras proporcionais a `pesos`, pelo método dos maiores restos.

    A soma das partes é sempre exatamente `total`; empates entre restos são decididos pela ordem dos pesos.
    """
    soma = sum(pesos)
    if total < 0 or soma <= 0 or any(p < 0 for p in pesos):
        raise ValueError("pesos devem ser não negativos com soma positiva, e o total não pode ser negativo")
    cotas = [total * p / soma for p in pesos]
    partes = [math.floor(c) for c in cotas]
    faltam = total - sum(partes)
    ordem = sorted(range(len(pesos)), key=lambda i: (-(cotas[i] - partes[i]), i))
    for i in ordem[:faltam]:
        partes[i] += 1
    return partes


def _cenario_alocacao(dims: dict, por_fase: dict, por_canal_fase: dict) -> dict:
    distribuido = CENARIO_TOTAL - CENARIO_TESTE_AB  # 97.200 entre as fases; a reserva fica fora do total
    unidades = round(distribuido / CENARIO_PASSO)
    pagos = [
        r["nome_canal"] for _, r in dims["Dim_Canal"].iterrows() if r["natureza_midia"] in NATUREZAS_PAGAS
    ]
    unidades_fase = distribuir_inteiros([por_fase[f]["share_pedidos"] for f in FASES], unidades)
    fases = {}
    for fase, n_fase in zip(FASES, unidades_fase):
        valor_fase = n_fase * float(CENARIO_PASSO)
        pesos = []
        for canal in pagos:
            custo = por_canal_fase[fase][canal]["custo_por_pedido"]
            pesos.append(1 / custo if custo else 0.0)  # canal sem pedidos (sem custo por pedido) não recebe
        unidades_canal = distribuir_inteiros(pesos, n_fase)
        canais = {
            canal: {
                "pct": _razao(n * CENARIO_PASSO, valor_fase),
                "pct_do_total": n * CENARIO_PASSO / CENARIO_TOTAL,
                "valor": n * float(CENARIO_PASSO),
            }
            for canal, n in zip(pagos, unidades_canal)
        }
        fases[fase] = {
            "pct": valor_fase / distribuido,
            "pct_do_total": valor_fase / CENARIO_TOTAL,
            "valor": valor_fase,
            "canais": canais,
        }
    return {
        "criterio": (
            "Cenário ilustrativo de redistribuição do histórico, não uma previsão de resultados. Dos R$ 108.000,00 "
            "distribuídos, 10% (R$ 10.800,00) ficam reservados para o teste A/B de peças e os R$ 97.200,00 restantes "
            "são divididos entre as duas fases na proporção da participação histórica de cada fase nos pedidos "
            "atribuídos. Dentro de cada fase, o valor é repartido entre os cinco canais pagos (Instagram Ads, TikTok "
            "Ads, Google Pesquisa, YouTube Ads e Influenciadores) em proporção ao inverso do custo por pedido "
            "histórico do canal naquela fase, de modo que o canal mais barato por pedido recebe a maior fatia. Cada "
            "valor é arredondado para múltiplos de R$ 100 pelo método dos maiores restos, o que mantém exatas as somas "
            "por fase e o total de R$ 108.000,00. A reserva de R$ 12.000,00 fica fora dessa distribuição e não é "
            "alocada. Canais sem custo direto (e-mail, redes sociais orgânicas e direto) não entram na divisão."
        ),
        "total": CENARIO_TOTAL,
        "reserva": CENARIO_RESERVA,
        "teste_ab": CENARIO_TESTE_AB,
        "fases": fases,
    }


# --- saída ---------------------------------------------------------------------------------------------

def _limpar(obj, chave: str | None = None):
    """Tipos nativos do Python, NaN/inf viram None e decimais são arredondados (reais: 2 casas; razões: 6)."""
    if isinstance(obj, dict):
        return {str(k): _limpar(v, str(k)) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_limpar(v, chave) for v in obj]
    if isinstance(obj, (bool, np.bool_)):
        return bool(obj)
    if isinstance(obj, (int, np.integer)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        x = float(obj)
        if not math.isfinite(x):
            return None
        return round(x, 2 if chave in CHAVES_EM_REAIS else 6)
    return obj


def calcular(pasta: Path) -> dict:
    """Calcula todos os resultados a partir da pasta de dados tratados (a saída do ETL)."""
    pasta = Path(pasta)
    base, dims = _montar_base(pasta)
    totais = _totais(base, dims)
    por_fase = _por_fase(base, totais)
    por_canal_fase = _por_canal_fase(base, dims)
    res = {
        "totais": totais,
        "por_canal": _por_canal(base, dims, totais),
        "por_fase": por_fase,
        "por_canal_fase": por_canal_fase,
        "por_semana": _por_semana(base, totais),
        "por_edicao": _por_edicao(base, dims),
        "por_regiao": _por_regiao(base, dims),
        "por_mensagem_peca": _por_mensagem_peca(base, dims),
        "temas_por_fase": _temas_por_fase(pasta, base),
        "mensal": _mensal(base),
        "orcamento_campanhas": _orcamento_campanhas(base, dims),
        "cenario_alocacao": _cenario_alocacao(dims, por_fase, por_canal_fase),
    }
    return _limpar(res)


def salvar(res: dict, caminho: Path) -> None:
    """Grava o JSON (UTF-8 sem BOM, acentos legíveis); recusa NaN/inf. Cria a pasta se preciso."""
    caminho = Path(caminho)
    texto = json.dumps(res, ensure_ascii=False, indent=2, allow_nan=False)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with open(caminho, "w", encoding="utf-8", newline="\n") as f:
        f.write(texto + "\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Calcula os resultados da análise (resultados.json).")
    ap.add_argument("--dados", type=Path, default=DADOS_PADRAO, help="pasta com os CSVs tratados do ETL")
    ap.add_argument("--saida", type=Path, default=SAIDA_PADRAO, help="caminho do JSON de resultados")
    args = ap.parse_args(argv)
    res = calcular(args.dados)
    salvar(res, args.saida)
    t = res["totais"]
    print(f"Resultados gravados em {args.saida}: {t['pedidos']} pedidos, {t['ingressos']} ingressos.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
