"""Figuras do relatório do caso Conecta Cultura (A3), geradas a partir de `resultados.json`.

Cada figura é um PNG de 300 dpi com 16 cm de largura (uma coluna de texto A4), rótulos em português e
números no formato brasileiro (1.234,56; percentual com vírgula). As legendas ficam nos documentos: nas
imagens há só rótulos de eixo (com unidade) e, quando preciso, uma nota curta.

Cores (paleta de referência da skill dataviz, validada com `validate_palette.js`):
- canal: uma cor fixa por canal em todas as figuras (as 8 posições categóricas, na ordem do Dim_Canal);
- fase: rampa ordinal de azul, Descoberta (claro) -> Convite (escuro);
- resultado (ingressos, taxas, ocupação): azul; investimento e custo: cinza neutro; ênfase: azul contra cinza.

Uso: python -m analise.figuras --resultados build/resultados.json --saida build/figuras
"""
import argparse
import json
import sys
import textwrap
from pathlib import Path

import matplotlib
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter, MaxNLocator

RAIZ = Path(__file__).resolve().parent.parent
RESULTADOS_PADRAO = RAIZ / "build" / "resultados.json"
SAIDA_PADRAO = RAIZ / "build" / "figuras"

DPI = 300
LARGURA_CM = 16.0
LARGURA = LARGURA_CM / 2.54  # polegadas

# Tinta e superfície (tokens da paleta de referência, modo claro; fundo branco para entrar em documentos).
SUPERFICIE = "#ffffff"
TINTA = "#0b0b0b"
TINTA_2 = "#52514e"
TINTA_FRACA = "#898781"
GRADE = "#e1e0d9"
BASE = "#c3c2b7"

# Posições categóricas 1 a 8, na ordem validada.
CATEGORICAS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
CANAIS = [
    "Instagram Ads", "TikTok Ads", "Google Pesquisa", "YouTube Ads",
    "Redes sociais orgânicas", "E-mail", "Influenciadores", "Direto",
]
COR_CANAL = dict(zip(CANAIS, CATEGORICAS))

COR_RESULTADO = CATEGORICAS[0]
COR_CUSTO = TINTA_FRACA
COR_OUTROS = BASE  # contexto, quando uma barra é destacada
COR_FASE = {"Descoberta": "#86b6ef", "Convite": "#184f95"}
COR_FUNIL = ["#86b6ef", "#2a78d6", "#184f95"]  # rampa ordinal, da etapa mais ampla à mais estreita

MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]
SEM_CUSTO = "sem custo direto"

ESTILO = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Inter", "Liberation Sans", "Arial", "DejaVu Sans"],
    "font.size": 7.5,
    "axes.titlesize": 7.5,
    "axes.labelsize": 7.5,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": 7,
    "text.color": TINTA,
    "axes.labelcolor": TINTA_2,
    "axes.titlecolor": TINTA_2,
    "xtick.color": TINTA_FRACA,
    "ytick.color": TINTA_FRACA,
    "axes.edgecolor": BASE,
    "axes.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.facecolor": SUPERFICIE,
    "figure.facecolor": SUPERFICIE,
    "savefig.facecolor": SUPERFICIE,
    "axes.axisbelow": True,
    "grid.color": GRADE,
    "grid.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
}


# --- formatação brasileira ---------------------------------------------------------------------------

def fmt_br(valor: float, casas: int = 0) -> str:
    """1234.5 -> '1.234,50' (milhar com ponto, decimal com vírgula)."""
    valor = float(valor)
    if round(valor, casas) == 0:
        valor = 0.0  # evita '-0'
    return f"{valor:,.{casas}f}".replace(",", "\0").replace(".", ",").replace("\0", ".")


def fmt_pct(razao: float, casas: int = 1) -> str:
    """0.5418 -> '54,2%'."""
    return fmt_br(razao * 100, casas) + "%"


def fmt_reais(valor: float, casas: int = 2) -> str:
    return "R$ " + fmt_br(valor, casas)


def _eixo_br(casas: int = 0) -> FuncFormatter:
    return FuncFormatter(lambda v, _pos: fmt_br(v, casas))


def _eixo_pct() -> FuncFormatter:
    return FuncFormatter(lambda v, _pos: fmt_pct(v, 0))


# --- peças comuns -----------------------------------------------------------------------------------------

def _nova(altura_cm: float) -> Figure:
    return Figure(figsize=(LARGURA, altura_cm / 2.54), layout="constrained")


def _grade(ax, eixo: str) -> None:
    ax.grid(axis=eixo, linewidth=0.6, color=GRADE)
    ax.tick_params(axis=eixo, length=0)


def _sem_eixo_de_valores(ax, eixo: str = "x") -> None:
    """Quando todo valor está escrito na barra, a escala é redundante: some com ela."""
    if eixo == "x":
        ax.set_xticks([])
        ax.spines["bottom"].set_visible(False)
    else:
        ax.set_yticks([])
        ax.spines["left"].set_visible(False)


def _barras_h(ax, rotulos, valores, cores, altura=0.58):
    """Barras horizontais, a primeira no topo, finas e sobre uma única linha de base."""
    y = list(range(len(rotulos)))
    ax.barh(y, valores, height=altura, color=cores, linewidth=0)
    ax.set_yticks(y, rotulos)
    if not ax.yaxis_inverted():  # com sharey o eixo é um só: inverter de novo desfaria a inversão
        ax.invert_yaxis()
    ax.tick_params(axis="y", length=0, labelcolor=TINTA)
    ax.spines["left"].set_color(BASE)
    ax.margins(y=0.04)
    return y


def _rotulo_na_ponta(ax, x, y, texto, margem, cor=TINTA, **kw):
    ax.text(x + margem, y, texto, va="center", ha="left", fontsize=7, color=cor, **kw)


def _quebrar(texto: str, largura: int) -> str:
    return "\n".join(textwrap.wrap(texto, largura))


def _salvar(fig: Figure, pasta: Path, nome: str) -> Path:
    caminho = pasta / nome
    fig.savefig(caminho, dpi=DPI)  # sem bbox_inches="tight": a largura fica exatamente em 16 cm
    return caminho


def _ordem_canais_por_pedidos(por_canal: dict) -> list[str]:
    return sorted(por_canal, key=lambda c: (-por_canal[c]["pedidos"], CANAIS.index(c)))


# --- fig1: série mensal ----------------------------------------------------------------------------------

def _fig_mensal(res: dict) -> Figure:
    mensal = res["mensal"]
    x = list(range(len(mensal)))
    rotulos = [MESES[int(m["ano_mes"][5:7]) - 1] for m in mensal]
    fig = _nova(9.6)
    ax_a, ax_b = fig.subplots(2, 1, sharex=True)

    paineis = [
        (ax_a, "ingressos", COR_RESULTADO, "Ingressos vendidos (unidades por mês)", lambda v: fmt_br(v)),
        (ax_b, "investimento", COR_CUSTO, "Investimento em mídia paga (R$ por mês)", lambda v: fmt_br(v)),
    ]
    for ax, chave, cor, titulo, fmt in paineis:
        valores = [m[chave] for m in mensal]
        ax.bar(x, valores, width=0.62, color=cor, linewidth=0)
        ax.set_title(titulo, loc="left", pad=6)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4, steps=[1, 2, 5, 10], integer=True))
        ax.yaxis.set_major_formatter(_eixo_br())
        ax.set_ylim(0, max(valores) * 1.18)
        _grade(ax, "y")
        pico = max(x, key=lambda i: valores[i])  # único rótulo: o mês de maior valor
        ax.annotate(
            fmt(valores[pico]), xy=(pico, valores[pico]), xytext=(0, 2.5), textcoords="offset points",
            ha="center", va="bottom", fontsize=7, color=TINTA,
        )
    ax_a.tick_params(axis="x", length=0)
    ax_b.set_xticks(x, rotulos)
    ax_b.tick_params(axis="x", length=0, labelsize=6.8)
    ax_b.set_xlim(-0.7, len(mensal) - 0.3)

    # Ano sob os meses, com um traço por grupo.
    anos = {}
    for i, m in enumerate(mensal):
        anos.setdefault(m["ano_mes"][:4], []).append(i)
    for ano, posicoes in anos.items():
        ini, fim = posicoes[0], posicoes[-1]
        ax_b.annotate(
            "", xy=(fim + 0.4, -0.17), xytext=(ini - 0.4, -0.17),
            xycoords=("data", "axes fraction"), textcoords=("data", "axes fraction"),
            arrowprops={"arrowstyle": "-", "color": BASE, "lw": 0.8, "shrinkA": 0, "shrinkB": 0},
            annotation_clip=False,
        )
        ax_b.annotate(
            ano, xy=((ini + fim) / 2, -0.17), xycoords=("data", "axes fraction"),
            xytext=(0, -2), textcoords="offset points", ha="center", va="top", fontsize=7, color=TINTA_2,
        )
    return fig


# --- fig2: canais -----------------------------------------------------------------------------------------

def _fig_canais(res: dict) -> Figure:
    por_canal = res["por_canal"]
    ordem = _ordem_canais_por_pedidos(por_canal)
    cores = [COR_CANAL[c] for c in ordem]
    fig = _nova(8.2)
    ax_cliques, ax_pedidos, ax_custo = fig.subplots(
        1, 3, sharey=True, gridspec_kw={"width_ratios": [1.15, 1, 1]}
    )

    paineis = [
        (ax_cliques, "cliques", "Cliques (nº)", 0),
        (ax_pedidos, "pedidos", "Pedidos confirmados (nº)", 0),
    ]
    for ax, chave, titulo, casas in paineis:
        valores = [por_canal[c][chave] for c in ordem]
        y = _barras_h(ax, ordem, valores, cores)
        maximo = max(valores)
        ax.set_xlim(0, maximo * 1.36)
        for yi, v in zip(y, valores):
            if v == 0:
                _rotulo_na_ponta(ax, 0, yi, "sem cliques", maximo * 0.015, cor=TINTA_FRACA, style="italic")
            else:
                _rotulo_na_ponta(ax, v, yi, fmt_br(v, casas), maximo * 0.015)
        ax.set_xlabel(titulo)
        _sem_eixo_de_valores(ax)

    valores = [por_canal[c]["custo_por_pedido"] for c in ordem]
    reais = [v for v in valores if v is not None]
    maximo = max(reais)
    y = _barras_h(ax_custo, ordem, [v or 0 for v in valores], cores)
    ax_custo.set_xlim(0, maximo * 1.7)
    for yi, v in zip(y, valores):
        if v is None:
            _rotulo_na_ponta(ax_custo, 0, yi, SEM_CUSTO, maximo * 0.015, cor=TINTA_FRACA, style="italic")
        else:
            _rotulo_na_ponta(ax_custo, v, yi, fmt_reais(v), maximo * 0.015)
    ax_custo.set_xlabel("Custo por pedido (R$)")
    _sem_eixo_de_valores(ax_custo)
    for ax in (ax_pedidos, ax_custo):
        ax.spines["left"].set_visible(False)
    return fig


# --- fig3: mensagem da peça ----------------------------------------------------------------------------

def _fig_pecas(res: dict) -> Figure:
    pecas = res["por_mensagem_peca"]
    # Custo de mídia por pedido de canal pago (não o misto, que dilui o custo nos pedidos sem custo direto).
    ordem = sorted(pecas, key=lambda m: (pecas[m]["custo_por_pedido_pago"], m))  # mais barato primeiro
    rotulos = [_quebrar(m, 22) for m in ordem]
    fig = _nova(6.4)
    ax_custo, ax_taxa = fig.subplots(1, 2, sharey=True)

    valores = [pecas[m]["custo_por_pedido_pago"] for m in ordem]
    y = _barras_h(ax_custo, rotulos, valores, COR_CUSTO)
    ax_custo.set_xlim(0, max(valores) * 1.3)
    for yi, v in zip(y, valores):
        _rotulo_na_ponta(ax_custo, v, yi, fmt_reais(v), max(valores) * 0.015)
    ax_custo.set_xlabel("Custo de mídia por pedido\nde canal pago (R$)")
    _sem_eixo_de_valores(ax_custo)

    valores = [pecas[m]["taxa_checkout"] for m in ordem]
    _barras_h(ax_taxa, rotulos, valores, COR_RESULTADO)
    ax_taxa.set_xlim(0, max(valores) * 1.3)
    for yi, v in zip(y, valores):
        _rotulo_na_ponta(ax_taxa, v, yi, fmt_pct(v), max(valores) * 0.015)
    ax_taxa.set_xlabel("Taxa de início de checkout (% das sessões)")
    _sem_eixo_de_valores(ax_taxa)
    ax_taxa.spines["left"].set_visible(False)
    return fig


# --- fig4: edições -----------------------------------------------------------------------------------------

def _fig_edicoes(res: dict) -> Figure:
    edicoes = res["por_edicao"]  # na ordem cronológica
    nomes = list(edicoes)
    rotulos = [n.removeprefix("Conecta ") for n in nomes]
    valores = [edicoes[n]["ocupacao"] for n in nomes]
    destaque = "Conecta Belo Horizonte 2024"
    cores = [COR_RESULTADO if n == destaque else COR_OUTROS for n in nomes]
    fig = _nova(8.4)
    ax = fig.subplots()
    y = _barras_h(ax, rotulos, valores, cores, altura=0.62)
    for tick, n in zip(ax.get_yticklabels(), nomes):
        if n == destaque:
            tick.set_fontweight("semibold")
    ax.set_xlim(0, 1.0)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.xaxis.set_major_formatter(_eixo_pct())
    for yi, v, n in zip(y, valores, nomes):  # valores em coluna, à direita da linha de referência
        _rotulo_na_ponta(
            ax, 0.62, yi, fmt_pct(v), 0, fontweight="semibold" if n == destaque else "normal"
        )
    total = res["totais"]["ocupacao"]
    ax.axvline(total, color=TINTA_2, linewidth=0.9, zorder=3)
    ax.annotate(
        f"conjunto das 12 edições: {fmt_pct(total)}", xy=(total, 1.0), xycoords=("data", "axes fraction"),
        xytext=(4, 4), textcoords="offset points", ha="left", va="bottom", fontsize=7, color=TINTA_2,
    )
    ax.set_xlabel("Ocupação atribuída (% da capacidade de 6.000 ingressos por edição)")
    return fig


# --- fig5: funil -------------------------------------------------------------------------------------------

def _fig_funil(res: dict) -> Figure:
    t = res["totais"]
    etapas = [
        ("Sessões", t["sessoes"]),
        ("Inícios de checkout", t["checkouts"]),
        ("Pedidos confirmados", t["pedidos"]),
    ]
    rotulos = [e[0] for e in etapas]
    valores = [e[1] for e in etapas]
    fig = _nova(5.4)
    ax = fig.subplots()
    y = _barras_h(ax, rotulos, valores, COR_FUNIL, altura=0.56)
    ax.set_xlim(0, valores[0] * 1.5)
    margem = valores[0] * 0.012
    for yi, v in zip(y, valores):
        _rotulo_na_ponta(ax, v, yi, f"{fmt_br(v)}  ({fmt_pct(v / valores[0])} das sessões)", margem)
    # Passagem entre as duas últimas etapas.
    ax.annotate(
        f"{fmt_pct(t['conclusao_checkout'])} dos inícios de checkout viram pedido",
        xy=(valores[1] + valores[0] * 0.012, 1.5), xytext=(valores[1] + valores[0] * 0.012, 1.5),
        va="center", ha="left", fontsize=7, color=TINTA_2, style="italic",
    )
    ax.set_xlabel("Volume acumulado, set/2024 a ago/2026 (nº)")
    _sem_eixo_de_valores(ax)
    return fig


# --- fig6: temas das dúvidas por fase -----------------------------------------------------------------

def _fig_temas_fase(res: dict) -> Figure:
    t = res["temas_por_fase"]
    temas = list(t["duvidas_por_tema"])  # do mais ao menos citado
    fig = _nova(8.6)
    ax = fig.subplots()
    altura = 0.34
    maximo = max(n for f in t["por_fase"].values() for n in f.values())
    ax.set_xlim(0, maximo * 1.42)
    centros = list(range(len(temas)))
    for k, fase in enumerate(("Descoberta", "Convite")):
        deslocamento = (k - 0.5) * (altura + 0.04)
        ys = [c + deslocamento for c in centros]
        valores = [t["por_fase"][fase][tema] for tema in temas]
        ax.barh(
            ys, valores, height=altura, color=COR_FASE[fase], linewidth=0,
            label=f"{fase} (n = {fmt_br(t['duvidas_por_fase'][fase])} dúvidas)",
        )
        for yi, v, tema in zip(ys, valores, temas):
            share = t["share_por_fase"][fase][tema]
            _rotulo_na_ponta(ax, v, yi, f"{fmt_br(v)}  ({fmt_pct(share)})", maximo * 0.012)
    ax.set_yticks(centros, temas)
    ax.invert_yaxis()
    ax.tick_params(axis="y", length=0, labelcolor=TINTA)
    ax.margins(y=0.03)
    _sem_eixo_de_valores(ax)
    ax.set_xlabel("Dúvidas (nº de mensagens e % das dúvidas da fase)")
    ax.legend(loc="lower right", frameon=False, handlelength=1.2, handleheight=0.9, borderaxespad=0.2)
    ax.annotate(
        f"n = {fmt_br(t['duvidas_total'])} dúvidas em {fmt_br(t['mensagens_total'])} mensagens",
        xy=(1.0, 0.0), xycoords="axes fraction", xytext=(0, 36), textcoords="offset points",
        ha="right", va="bottom", fontsize=7, color=TINTA_2, style="italic",
    )
    return fig


# --- fig7: semanas antes do evento ------------------------------------------------------------------------

def _fig_semanas(res: dict) -> Figure:
    semanas = res["por_semana"]
    ordem = [str(n) for n in range(8, -1, -1)]  # S-8 ... S-0, o tempo corre rumo ao evento
    x = list(range(len(ordem)))
    valores = [semanas[s]["ingressos"] for s in ordem]
    fases = [semanas[s]["fase"] for s in ordem]
    cores = [COR_FASE[f] for f in fases]
    fig = _nova(7.4)
    ax = fig.subplots()
    ax.bar(x, valores, width=0.62, color=cores, linewidth=0)
    maximo = max(valores)
    ax.set_ylim(0, maximo * 1.3)
    for xi, s, v in zip(x, ordem, valores):
        ax.annotate(
            f"{fmt_br(v)}\n{fmt_pct(semanas[s]['share_ingressos'])}", xy=(xi, v), xytext=(0, 2.5),
            textcoords="offset points", ha="center", va="bottom", fontsize=7, color=TINTA, linespacing=1.15,
        )
    rotulos = [f"S-{s}" for s in ordem]
    rotulos[-1] = "S-0\n(só o dia\ndo evento)"
    ax.set_xticks(x, rotulos)
    ax.tick_params(axis="x", length=0, labelcolor=TINTA_2)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4, steps=[1, 2, 5, 10], integer=True))
    ax.yaxis.set_major_formatter(_eixo_br())
    _grade(ax, "y")
    ax.set_xlim(-0.6, len(ordem) - 0.4)
    ax.set_ylabel("Ingressos vendidos (unidades por semana)")
    ax.set_xlabel("Semanas antes do evento (S-n: n semanas antes da data da edição)")

    # Nomes das fases sobre cada grupo de semanas, ligados por um traço.
    for fase in ("Descoberta", "Convite"):
        pos = [i for i, f in enumerate(fases) if f == fase]
        ini, fim = pos[0] - 0.4, pos[-1] + 0.4
        n_semanas = f"S-{ordem[pos[0]]} a S-{ordem[pos[-1]]}"
        ax.annotate(
            "", xy=(fim, 0.965), xytext=(ini, 0.965), xycoords=("data", "axes fraction"),
            textcoords=("data", "axes fraction"),
            arrowprops={"arrowstyle": "-", "color": COR_FASE[fase], "lw": 2.0, "shrinkA": 0, "shrinkB": 0},
        )
        ax.annotate(
            f"{fase} ({n_semanas})", xy=((ini + fim) / 2, 0.965), xycoords=("data", "axes fraction"),
            xytext=(0, 3), textcoords="offset points", ha="center", va="bottom", fontsize=7, color=TINTA_2,
        )
    return fig


# --- geração -----------------------------------------------------------------------------------------------

FIGURAS = [
    ("fig1_mensal.png", _fig_mensal),
    ("fig2_canais.png", _fig_canais),
    ("fig3_pecas.png", _fig_pecas),
    ("fig4_edicoes.png", _fig_edicoes),
    ("fig5_funil.png", _fig_funil),
    ("fig6_temas_fase.png", _fig_temas_fase),
    ("fig7_semanas.png", _fig_semanas),
]


def gerar(res: dict, pasta: Path) -> list[Path]:
    """Gera as figuras em `pasta` (criada se preciso) e devolve os caminhos, na ordem de FIGURAS."""
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    caminhos = []
    with matplotlib.rc_context(ESTILO):
        for nome, desenhar in FIGURAS:
            caminhos.append(_salvar(desenhar(res), pasta, nome))
    return caminhos


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Gera as figuras do relatório a partir de resultados.json.")
    ap.add_argument("--resultados", type=Path, default=RESULTADOS_PADRAO, help="JSON gerado por analise.resultados")
    ap.add_argument("--saida", type=Path, default=SAIDA_PADRAO, help="pasta de saída dos PNG")
    args = ap.parse_args(argv)
    res = json.loads(args.resultados.read_text(encoding="utf-8"))
    for caminho in gerar(res, args.saida):
        print(caminho)
    return 0


if __name__ == "__main__":
    sys.exit(main())
