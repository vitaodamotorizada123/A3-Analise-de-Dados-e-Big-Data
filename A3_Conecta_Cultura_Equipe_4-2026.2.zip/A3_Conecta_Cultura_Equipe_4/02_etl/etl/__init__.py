"""ETL do caso Conecta Cultura (A3): leitura, conferências, transformações e saídas."""
