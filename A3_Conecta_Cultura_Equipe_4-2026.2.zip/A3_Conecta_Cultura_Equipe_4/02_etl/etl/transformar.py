"""Colunas derivadas da fato: tema/tipo das mensagens, semanas até o evento e contagem de mensagens.

Nenhuma função altera os DataFrames recebidos; todas devolvem um DataFrame novo com as colunas
originais intactas, as colunas novas ao final, e as linhas na mesma ordem.
"""
import pandas as pd

from etl.temas import COLUNA_DUVIDA, classificar

COLUNA_POSITIVAS = "msg_positivas"
COLUNA_SUGESTOES = "msg_sugestoes"

# Ordem das colunas de mensagens acrescentadas à fato.
COLUNAS_MENSAGENS = [*COLUNA_DUVIDA.values(), COLUNA_POSITIVAS, COLUNA_SUGESTOES]


def classificar_interacoes(inter: pd.DataFrame) -> pd.DataFrame:
    """Acrescenta `tema` e `tipo` a cada mensagem (ver `temas.classificar`)."""
    res = inter.copy()
    pares = [classificar(texto) for texto in res["mensagem"]]
    res["tema"] = [tema for tema, _ in pares]
    res["tipo"] = [tipo for _, tipo in pares]
    return res


def adicionar_semanas(fato: pd.DataFrame, dim_evento: pd.DataFrame) -> pd.DataFrame:
    """Acrescenta `dias_ate_evento` (data do evento - data) e `semana_antes_evento` (= ceil(dias / 7)).

    A data do evento vem de `dim_evento` por `id_evento`; 0 dia até o evento é a semana 0.
    """
    eventos = dim_evento[["id_evento", "data_evento"]]
    res = fato.merge(eventos, on="id_evento", how="left", validate="many_to_one")
    res.index = fato.index  # o merge devolve índice novo; a ordem das linhas é a da entrada

    data_evento = pd.to_datetime(res.pop("data_evento"), format="%Y-%m-%d")
    sem_evento = data_evento.isna()
    if sem_evento.any():
        ids = sorted(res.loc[sem_evento, "id_evento"].unique())
        raise ValueError(f"id_evento sem data em Dim_Evento: {ids}")

    dias = (data_evento - pd.to_datetime(res["data"], format="%Y-%m-%d")).dt.days.astype("int64")
    res["dias_ate_evento"] = dias
    res["semana_antes_evento"] = (-(-dias // 7)).astype("int64")  # teto da divisão inteira
    return res


def agregar_mensagens(fato: pd.DataFrame, inter_classif: pd.DataFrame) -> pd.DataFrame:
    """Acrescenta à fato a contagem de mensagens por linha (`id_registro`), sem repetir linhas.

    Colunas: uma `duv_*` por tema (só dúvidas), `msg_positivas` e `msg_sugestoes`; 0 quando não há mensagem.
    """
    msgs = inter_classif[["id_registro", "tema", "tipo"]].copy()

    sem_registro = ~msgs["id_registro"].isin(fato["id_registro"])
    if sem_registro.any():
        ids = sorted(msgs.loc[sem_registro, "id_registro"].unique())
        raise ValueError(f"mensagens de id_registro que não está na fato: {ids}")

    coluna = msgs["tipo"].map({"positivo": COLUNA_POSITIVAS, "sugestão": COLUNA_SUGESTOES})
    duvidas = msgs["tipo"] == "dúvida"
    coluna[duvidas] = msgs.loc[duvidas, "tema"].map(COLUNA_DUVIDA)
    if coluna.isna().any():
        pares = sorted({tuple(p) for p in msgs.loc[coluna.isna(), ["tema", "tipo"]].to_numpy()})
        raise ValueError(f"mensagens sem tema ou tipo classificado: {pares}")
    msgs["coluna"] = coluna

    contagem = msgs.groupby(["id_registro", "coluna"]).size().rename("n").reset_index()
    largo = contagem.pivot(index="id_registro", columns="coluna", values="n")
    largo = largo.reindex(columns=COLUNAS_MENSAGENS).reset_index()

    res = fato.merge(largo, on="id_registro", how="left", validate="one_to_one")
    res.index = fato.index
    res[COLUNAS_MENSAGENS] = res[COLUNAS_MENSAGENS].fillna(0).astype("int64")
    return res


def amostra_conferencia(inter_classif: pd.DataFrame, n: int = 150, semente: int = 20261031) -> pd.DataFrame:
    """Amostra aleatória reprodutível de `n` mensagens classificadas, para conferência manual.

    Ordenada por `id_interacao`, com índice 0..n-1.
    """
    amostra = inter_classif.sample(n=n, random_state=semente)
    return amostra.sort_values("id_interacao").reset_index(drop=True)
