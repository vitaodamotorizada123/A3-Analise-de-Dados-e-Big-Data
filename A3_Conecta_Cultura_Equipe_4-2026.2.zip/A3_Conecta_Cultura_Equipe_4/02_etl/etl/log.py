"""Escrita do `log_etl.md`: conferências, transformações e exercício de ETL, em português.

O log vai para o documento técnico, então a palavra APROVADO aparece uma única vez por conferência
aprovada (na tabela das conferências); nas demais seções o resultado é escrito como OK ou FALHOU.
"""
import re
from datetime import datetime
from pathlib import Path

import pandas as pd

from etl import config
from etl.conferencias import Conferencia, _n
from etl.exercicio import REGRA_DUPLICATA, REGRA_ESPACOS_CAIXA, REGRA_VAZIO
from etl.temas import COLUNA_DUVIDA
from etl.transformar import COLUNA_POSITIVAS, COLUNA_SUGESTOES

# Conferência manual da amostra de mensagens (feita na etapa de classificação, ver etl.transformar).
AMOSTRA_N = 150
AMOSTRA_SEMENTE = 20261031
TEXTO_AMOSTRA = (
    f"Amostra de {AMOSTRA_N} mensagens (semente {AMOSTRA_SEMENTE}): {AMOSTRA_N}/{AMOSTRA_N} classificações "
    "conferidas manualmente contra as regras. "
    'O tipo "dúvida" reúne dúvidas, barreiras e pedidos de informação.'
)

REGRAS_SEMANAS = {
    "dias_ate_evento": "data do evento (Dim_Evento) menos `data`, em dias",
    "semana_antes_evento": "teto de `dias_ate_evento` / 7 (0 = dia do evento)",
}

REGRAS_MENSAGENS = {
    **{coluna: f"mensagens de tipo dúvida no tema {tema}" for tema, coluna in COLUNA_DUVIDA.items()},
    COLUNA_POSITIVAS: "mensagens de tipo positivo, de qualquer tema",
    COLUNA_SUGESTOES: "mensagens de tipo sugestão, de qualquer tema",
}

REGRAS_EXERCICIO = [
    (REGRA_ESPACOS_CAIXA, "tira os espaços das pontas e usa a caixa do nome oficial do canal (Dim_Canal)"),
    (REGRA_VAZIO, "canal vazio recebe o nome do Dim_Canal para o `id_canal` da própria linha"),
    (REGRA_DUPLICATA, "linha repetida pelo `id_registro` é removida; fica a primeira"),
]


def _celula(texto) -> str:
    """Texto de uma célula de tabela: numa linha só e com a barra vertical escapada."""
    return " ".join(str(texto).split()).replace("|", "\\|")


def _literal(valor) -> str:
    """Valor entre aspas dentro de um trecho de código, para deixar à vista vazios e espaços nas pontas."""
    texto = str(valor).replace("\r", " ").replace("\n", " ").replace("|", "\\|")
    return f'`"{texto}"`'


def _nome_da_pasta(caminho) -> str:
    """Só o nome da pasta (última parte do caminho, com / ou \\): o log não mostra onde o ETL rodou."""
    return re.split(r"[\\/]", str(caminho).rstrip("\\/"))[-1]


def _resultado(ok: bool) -> str:
    return "OK" if ok else "FALHOU"


def _tabela(cabecalho: list[str], linhas: list[list[str]], alinhar_direita: tuple[int, ...] = ()) -> list[str]:
    separador = ["---:" if i in alinhar_direita else "---" for i in range(len(cabecalho))]
    return [
        "| " + " | ".join(cabecalho) + " |",
        "| " + " | ".join(separador) + " |",
        *("| " + " | ".join(linha) + " |" for linha in linhas),
    ]


def _secao_cabecalho(conferencias, resumo) -> list[str]:
    executado_em = resumo.get("executado_em") or datetime.now()
    aprovadas = sum(c.ok for c in conferencias)
    verificacoes = resumo["verificacoes"]
    comparacao = resumo["comparacao_exercicio"]
    return [
        "# Log do ETL - Conecta Cultura (A3)",
        "",
        f"- **Execução:** {executado_em:%Y-%m-%d %H:%M:%S}",
        f"- **Origem:** pasta `{_nome_da_pasta(resumo['origem'])}`",
        f"- **Destino:** pasta `{_nome_da_pasta(resumo['destino'])}`",
        f"- **Resultado geral:** {aprovadas} de {len(conferencias)} conferências aprovadas; "
        f"transformações {_resultado(all(v.ok for v in verificacoes))}; "
        f"exercício de ETL {_resultado(comparacao.ok)}",
        "",
    ]


def _secao_conferencias(conferencias: list[Conferencia]) -> list[str]:
    linhas = [
        [str(i), _celula(c.nome), "APROVADO" if c.ok else "REPROVADO", _celula(c.detalhe)]
        for i, c in enumerate(conferencias, start=1)
    ]
    return [
        "## Conferências de integridade",
        "",
        *_tabela(["nº", "Conferência", "Resultado", "Detalhe"], linhas),
        "",
    ]


def _tabela_tema_tipo(tema_tipo: pd.DataFrame) -> list[str]:
    tipos = list(tema_tipo.columns)
    linhas = [
        [_celula(tema), *(_n(v) for v in valores), _n(sum(valores))]
        for tema, valores in zip(tema_tipo.index, tema_tipo.to_numpy().tolist())
    ]
    totais = tema_tipo.sum(axis=0).tolist()
    linhas.append(["Total", *(_n(v) for v in totais), _n(sum(totais))])
    colunas_numericas = tuple(range(1, len(tipos) + 2))
    return _tabela(["Tema", *map(_celula, tipos), "Total"], linhas, alinhar_direita=colunas_numericas)


def _linhas_verificacoes(resumo) -> list[str]:
    return [f"- {_resultado(v.ok)}: {_celula(v.nome)} - {_celula(v.detalhe)}" for v in resumo["verificacoes"]]


def _secao_colunas_novas(resumo) -> list[str]:
    totais = resumo["colunas_mensagens"]
    if totais is None:  # a fato tratada não foi gerada: não há colunas, linhas nem somas a mostrar
        return [
            "A fato tratada não foi gerada: as colunas novas, as linhas e a soma das mensagens "
            "não puderam ser calculadas.",
            "",
            *_linhas_verificacoes(resumo),
            "",
        ]
    soma = sum(totais.values())
    linhas_semanas = [[coluna, regra] for coluna, regra in REGRAS_SEMANAS.items()]
    linhas_mensagens = [
        [coluna, REGRAS_MENSAGENS.get(coluna, "contagem de mensagens"), _n(total)]
        for coluna, total in totais.items()
    ]
    linhas_mensagens.append(["**Soma**", "", _n(soma)])
    antes, depois = resumo["linhas_antes"], resumo["linhas_depois"]
    return [
        f"A fato recebe {len(REGRAS_SEMANAS) + len(totais)} colunas novas ao final; "
        "as colunas, as linhas e os valores originais ficam como estão.",
        "",
        "### Semanas até o evento",
        "",
        *_tabela(["Coluna", "Regra"], linhas_semanas),
        "",
        "### Mensagens do público por linha da fato (contagem por `id_registro`; 0 quando não há mensagem)",
        "",
        *_tabela(["Coluna", "Regra", "Mensagens"], linhas_mensagens, alinhar_direita=(2,)),
        "",
        f"- Linhas da fato antes e depois: {_n(antes)} {'=' if antes == depois else '≠'} {_n(depois)}",
        f"- Soma das {len(totais)} colunas de mensagens = {_n(soma)}",
        *_linhas_verificacoes(resumo),
        "",
    ]


def _secao_transformacoes(resumo) -> list[str]:
    return [
        "## Transformações",
        "",
        *_secao_colunas_novas(resumo),
        "### Classificação das mensagens",
        "",
        TEXTO_AMOSTRA,
        "",
        "Mensagens por tema e tipo:",
        "",
        *_tabela_tema_tipo(resumo["tema_tipo"]),
        "",
    ]


def _linhas_extrato(resumo) -> str:
    antes, depois = resumo["extrato_linhas_antes"], resumo["extrato_linhas_depois"]
    if depois is None:  # a limpeza não terminou
        return f"{_n(antes)} no extrato; limpeza não concluída" if antes is not None else "extrato não lido"
    return f"{_n(antes)} no extrato, {_n(depois)} depois da limpeza"


def _secao_exercicio(exemplos: list[dict], resumo) -> list[str]:
    comparacao = resumo["comparacao_exercicio"]
    linhas = [
        [
            _celula(e["id_registro"]),
            _literal(e["antes"]),
            _literal(e["depois"]),
            _celula(e["regra"]),
        ]
        for e in exemplos
    ]
    if resumo["extrato_linhas_depois"] is None:
        tabela_antes_depois = ["Sem tabela de antes e depois: a limpeza do extrato não foi concluída."]
    else:
        tabela_antes_depois = [
            "Antes e depois de cada alteração (entre aspas, para mostrar vazios e espaços):",
            "",
            *_tabela(["id_registro", "antes", "depois", "regra"], linhas),
        ]
    return [
        "## Exercício de ETL",
        "",
        "Cópia de treinamento isolada (`Extrato_Para_Limpeza.csv`): não é anexada à fato nem ao modelo.",
        "",
        f"- Linhas: {_linhas_extrato(resumo)}",
        f"- Comparação com as {config.LINHAS_EXERCICIO} primeiras linhas da fato: "
        f"{_resultado(comparacao.ok)} - {_celula(comparacao.detalhe)}",
        "- Regras, nesta ordem:",
        *(f"  {i}. `{regra}`: {descricao}" for i, (regra, descricao) in enumerate(REGRAS_EXERCICIO, start=1)),
        "",
        *tabela_antes_depois,
        "",
    ]


def escrever_log(
    caminho: Path,
    conferencias: list[Conferencia],
    exemplos_exercicio: list[dict],
    resumo_transformacoes: dict,
) -> None:
    """Grava o log em Markdown (UTF-8 sem BOM) em `caminho`.

    `conferencias`: as 11 conferências, na ordem. `exemplos_exercicio`: a lista de `limpar_extrato`
    (dicts com id_registro, antes, depois, regra).

    `resumo_transformacoes` é um dict com as chaves:
      origem, destino            pastas de entrada e saída (Path ou texto); o cabeçalho mostra só o nome de cada uma;
      executado_em               datetime da execução (opcional; padrão: agora);
      linhas_antes, linhas_depois  linhas da fato antes e depois das transformações;
      colunas_mensagens          dict coluna -> total de mensagens, na ordem das 8 colunas;
      tema_tipo                  DataFrame de contagens (índice = tema, colunas = tipo);
      verificacoes               lista de Conferencia das transformações;
      extrato_linhas_antes, extrato_linhas_depois  linhas do extrato do exercício antes e depois;
      comparacao_exercicio       Conferencia da comparação do exercício com a fonte.

    Quando a fato tratada não pôde ser gerada, `colunas_mensagens` e `linhas_depois` são None: o log
    registra a falha (em `verificacoes`) e pula as tabelas de colunas. Quando a limpeza do exercício
    não terminou, `extrato_linhas_depois` é None (e `extrato_linhas_antes` também, se o extrato nem
    foi lido) e `exemplos_exercicio` é vazio: o log pula a tabela de antes e depois.
    """
    linhas = [
        *_secao_cabecalho(conferencias, resumo_transformacoes),
        *_secao_conferencias(conferencias),
        *_secao_transformacoes(resumo_transformacoes),
        *_secao_exercicio(exemplos_exercicio, resumo_transformacoes),
    ]
    Path(caminho).write_text("\n".join(linhas), encoding="utf-8", newline="\n")
