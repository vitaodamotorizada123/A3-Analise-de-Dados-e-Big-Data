"""Exercício de ETL isolado: limpeza do `Extrato_Para_Limpeza.csv` (105 linhas -> 100 únicas).

O extrato reapresenta as 100 primeiras linhas da fato, com cinco linhas duplicadas e uma
coluna extra, `canal_informado`, com espaços, caixa diferente e quatro valores vazios.
Este módulo é uma cópia de treinamento: nada aqui é anexado à fato nem cria outra tabela fato.

Regras de `limpar_extrato`, nesta ordem:
  1. tira os espaços das pontas e converte a caixa para o nome oficial do `Dim_Canal`;
  2. canal vazio é recuperado pelo `id_canal` da própria linha;
  3. linhas repetidas pelo `id_registro` são removidas (fica a primeira).
"""
from pathlib import Path

import pandas as pd

from etl import config
from etl.carregar import converter_medidas, ler_csv
from etl.conferencias import Conferencia, _TOLERANCIA_TEXTO, _exemplos, _fim_de_lista, _n

COLUNA_CANAL = "canal_informado"

REGRA_ESPACOS_CAIXA = "espaços/caixa"
REGRA_VAZIO = "vazio recuperado pelo id_canal"
REGRA_DUPLICATA = "duplicata removida"

# Campos do extrato que existem na fato (19): são os comparados com a fonte.
COLUNAS_COMPARADAS = ["id_registro", *config.GRAO, *config.MEDIDAS]


def ler_extrato(pasta: Path) -> pd.DataFrame:
    """Lê o extrato como `ler_fato` lê a fato: texto em `object` (campo vazio continua "") e medidas numéricas."""
    return converter_medidas(ler_csv(Path(pasta) / config.ARQUIVO_EXTRATO))


def _conferir_repeticoes(limpo: pd.DataFrame) -> None:
    """Falha se um `id_registro` repetido tiver valores diferentes (a remoção perderia informação)."""
    repetidas = limpo[limpo["id_registro"].duplicated(keep=False)]
    diferentes = repetidas.groupby("id_registro", sort=False).nunique(dropna=False).gt(1)
    problemas = [
        f"{id_registro} ({', '.join(diferentes.columns[linha])})"
        for id_registro, linha in diferentes.iterrows()
        if linha.any()
    ]
    if problemas:
        raise ValueError("id_registro repetido com valores diferentes: " + _fim_de_lista(problemas))


def limpar_extrato(extrato: pd.DataFrame, dim_canal: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """Devolve o extrato limpo (colunas e ordem do extrato, índice 0..n-1) e a lista de exemplos.

    Cada exemplo é um dict `{"id_registro", "antes", "depois", "regra"}`: uma linha para cada alteração
    nas linhas que ficam (regras "espaços/caixa" e "vazio recuperado pelo id_canal") e uma para cada linha
    removida ("duplicata removida", com a posição 1-based da linha no extrato). Ordem: por regra, na
    ordem acima, e dentro dela na ordem do extrato. Nenhuma entrada é alterada.

    Gera ValueError para canal fora do `Dim_Canal`, canal vazio cujo `id_canal` não está no `Dim_Canal`
    e `id_registro` repetido com valores diferentes. Um nome válido de outro canal não é trocado:
    quem aponta a divergência é `comparar_com_fonte`.
    """
    limpo = extrato.reset_index(drop=True)  # cópia: o resto abaixo só atribui colunas
    bruto = limpo[COLUNA_CANAL].fillna("")
    aparado = bruto.str.strip()
    vazio = aparado == ""

    oficial_por_caixa = {nome.casefold(): nome for nome in dim_canal["nome_canal"]}
    oficial = aparado.str.casefold().map(oficial_por_caixa)
    desconhecido = ~vazio & oficial.isna()
    if desconhecido.any():
        raise ValueError("canal_informado fora do Dim_Canal: " + _exemplos(bruto[desconhecido].map(repr)))

    nome_por_id = dict(zip(dim_canal["id_canal"], dim_canal["nome_canal"]))
    do_id = limpo["id_canal"].map(nome_por_id)
    sem_nome = vazio & do_id.isna()
    if sem_nome.any():
        raise ValueError("canal_informado vazio e id_canal fora do Dim_Canal: " + _exemplos(limpo.loc[sem_nome, "id_canal"]))

    limpo[COLUNA_CANAL] = oficial.where(~vazio, do_id).astype(limpo[COLUNA_CANAL].dtype)

    _conferir_repeticoes(limpo)
    repetida = limpo["id_registro"].duplicated(keep="first")
    mantida = ~repetida

    exemplos = []
    alterada = mantida & ~vazio & (bruto != limpo[COLUNA_CANAL])
    for regra, linhas in ((REGRA_ESPACOS_CAIXA, alterada), (REGRA_VAZIO, mantida & vazio)):
        for i in limpo.index[linhas]:
            exemplos.append({
                "id_registro": limpo.at[i, "id_registro"],
                "antes": bruto[i],
                "depois": limpo.at[i, COLUNA_CANAL],
                "regra": regra,
            })

    primeira_posicao = {
        id_registro: i + 1 for i, id_registro in zip(limpo.index[mantida], limpo.loc[mantida, "id_registro"])
    }
    for i in limpo.index[repetida]:
        id_registro = limpo.at[i, "id_registro"]
        primeira = primeira_posicao[id_registro]
        exemplos.append({
            "id_registro": id_registro,
            "antes": f"linha {i + 1} do extrato (repete a linha {primeira})",
            "depois": f"removida; fica a linha {primeira}",
            "regra": REGRA_DUPLICATA,
        })

    return limpo[mantida].reset_index(drop=True), exemplos


def _diferentes(coluna: str, obtido: pd.Series, esperado: pd.Series) -> pd.Series:
    """Máscara das linhas em que `obtido` difere de `esperado` (valores monetários com a tolerância do projeto)."""
    ambos_ausentes = obtido.isna() & esperado.isna()
    if coluna in config.COLUNAS_MONETARIAS:
        iguais = (obtido - esperado).abs() <= config.TOLERANCIA
    else:
        iguais = obtido == esperado
    return ~(iguais | ambos_ausentes)


def comparar_com_fonte(limpo: pd.DataFrame, fato: pd.DataFrame, dim_canal: pd.DataFrame | None = None) -> Conferencia:
    """Confere o extrato limpo com as 100 primeiras linhas da fato, por `id_registro`.

    Aprova só se as mesmas 100 linhas únicas estiverem no resultado e os 19 campos da fato forem iguais
    (valores monetários com tolerância de R$ 0,005; `canal_informado` não entra nessa comparação).
    Com `dim_canal`, exige também que `canal_informado` seja o nome do `Dim_Canal` para o `id_canal` da
    linha; sem ele essa verificação não é feita e o detalhe diz isso.
    """
    nome = "Exercício de ETL = fonte"
    esperado = fato.head(config.LINHAS_EXERCICIO)
    ausentes = [c for c in COLUNAS_COMPARADAS if c not in limpo.columns]
    if dim_canal is not None and COLUNA_CANAL not in limpo.columns:
        ausentes.append(COLUNA_CANAL)
    if ausentes:
        return Conferencia(nome, False, "colunas ausentes no resultado: " + ", ".join(ausentes))

    problemas = []
    repetidos = limpo.loc[limpo["id_registro"].duplicated(), "id_registro"]
    if len(repetidos):
        problemas.append(f"id_registro repetido no resultado (ex.: {_exemplos(repetidos)})")
    faltando = esperado.loc[~esperado["id_registro"].isin(set(limpo["id_registro"])), "id_registro"]
    if len(faltando):
        problemas.append(f"{_n(len(faltando))} id_registro das {config.LINHAS_EXERCICIO} primeiras linhas da fato faltando (ex.: {_exemplos(faltando)})")
    sobrando = limpo.loc[~limpo["id_registro"].isin(set(esperado["id_registro"])), "id_registro"]
    if len(sobrando):
        problemas.append(f"{_n(len(sobrando))} id_registro fora das {config.LINHAS_EXERCICIO} primeiras linhas da fato (ex.: {_exemplos(sobrando)})")

    obtido = limpo.drop_duplicates("id_registro").set_index("id_registro")
    base = esperado.set_index("id_registro")
    comuns = base.index[base.index.isin(obtido.index)]
    obtido, base = obtido.loc[comuns], base.loc[comuns]
    for coluna in COLUNAS_COMPARADAS[1:]:
        if coluna in config.MEDIDAS and not pd.api.types.is_numeric_dtype(obtido[coluna]):
            problemas.append(f"{coluna}: coluna não numérica no resultado")
            continue
        divergentes = comuns[_diferentes(coluna, obtido[coluna], base[coluna]).to_numpy()]
        if len(divergentes):
            problemas.append(f"{coluna}: {_n(len(divergentes))} linha(s) diferente(s) da fato (ex.: {_exemplos(divergentes)})")

    if dim_canal is not None:
        nomes = dim_canal.drop_duplicates("id_canal").set_index("id_canal")["nome_canal"]
        errados = limpo.loc[limpo[COLUNA_CANAL] != limpo["id_canal"].map(nomes), "id_registro"]
        if len(errados):
            problemas.append(f"{COLUNA_CANAL}: {_n(len(errados))} linha(s) diferente(s) do nome no Dim_Canal (ex.: {_exemplos(errados)})")

    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    canal = (
        f"{COLUNA_CANAL} igual ao nome do Dim_Canal em todas"
        if dim_canal is not None
        else f"{COLUNA_CANAL} não conferido (Dim_Canal não informado)"
    )
    return Conferencia(
        nome, True,
        f"{_n(len(limpo))} linhas únicas; os {len(COLUNAS_COMPARADAS)} campos da fato iguais às {config.LINHAS_EXERCICIO} "
        f"primeiras linhas (valores monetários com tolerância de R$ {_TOLERANCIA_TEXTO}); {canal}",
    )
