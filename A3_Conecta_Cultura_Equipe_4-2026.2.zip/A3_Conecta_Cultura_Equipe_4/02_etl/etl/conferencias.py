"""As 11 conferências de integridade da especificação (seção 4), na ordem da especificação.

Cada conferência devolve `Conferencia(nome, ok, detalhe)`. O detalhe resume o que foi
conferido quando aprova e aponta o que falhou (com exemplos) quando reprova.
"""
import hashlib
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from etl import config
from etl.carregar import ler_csv


@dataclass
class Conferencia:
    nome: str
    ok: bool
    detalhe: str


def _n(valor) -> str:
    """Inteiro com ponto de milhar (100000 -> 100.000)."""
    return f"{int(valor):,}".replace(",", ".")


def _exemplos(valores, limite: int = 3) -> str:
    unicos = list(dict.fromkeys(str(v) for v in valores))
    resto = len(unicos) - limite
    texto = ", ".join(unicos[:limite])
    return texto + (f" e mais {resto}" if resto > 0 else "")


def _fim_de_lista(itens: list[str], limite: int = 6) -> str:
    resto = len(itens) - limite
    return "; ".join(itens[:limite]) + (f"; e mais {resto}" if resto > 0 else "")


# 1 ----------------------------------------------------------------------------------

def _sha256_do_arquivo(caminho: Path) -> str:
    resumo = hashlib.sha256()
    with caminho.open("rb") as arquivo:
        for bloco in iter(lambda: arquivo.read(1 << 20), b""):
            resumo.update(bloco)
    return resumo.hexdigest()


def _conferir_sha256(pasta: Path) -> Conferencia:
    nome = "SHA-256 = manifesto"
    caminho_manifesto = pasta / config.ARQUIVO_MANIFESTO
    if not caminho_manifesto.is_file():
        return Conferencia(nome, False, f"{config.ARQUIVO_MANIFESTO} não encontrado")
    manifesto = ler_csv(caminho_manifesto)
    ausentes, divergentes = [], []
    for arquivo, esperado in zip(manifesto["arquivo"], manifesto["sha256"]):
        caminho = pasta / arquivo
        if not caminho.is_file():
            ausentes.append(arquivo)
        elif _sha256_do_arquivo(caminho) != esperado.strip().lower():
            divergentes.append(arquivo)
    if ausentes or divergentes:
        partes = []
        if divergentes:
            partes.append("SHA-256 diferente: " + _fim_de_lista(divergentes))
        if ausentes:
            partes.append("arquivo ausente: " + _fim_de_lista(ausentes))
        return Conferencia(nome, False, "; ".join(partes))
    return Conferencia(nome, True, f"{len(manifesto)} arquivos listados no manifesto, todos com o mesmo SHA-256")


# 2 ----------------------------------------------------------------------------------

def _ler_inventario(pasta: Path) -> dict[str, int] | None:
    caminho = pasta / config.ARQUIVO_INVENTARIO
    if not caminho.is_file():
        return None
    tabelas = ler_csv(caminho)
    inventario = {}
    for tabela, registros in zip(tabelas["tabela"], tabelas["registros"]):
        try:
            inventario[tabela] = int(registros)
        except ValueError:
            pass
    return inventario


def _conferir_contagens(pasta: Path, dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "Contagens = inventário"
    inventario = _ler_inventario(pasta)
    obtido = {config.NOME_FATO: len(fato), **{tabela: len(df) for tabela, df in dims.items()}}
    problemas = []
    if inventario is None:
        problemas.append(f"{config.ARQUIVO_INVENTARIO} não encontrado")
    for tabela, esperado in config.ESPERADO_CONTAGENS.items():
        if obtido.get(tabela) != esperado:
            problemas.append(f"{tabela}: {obtido.get(tabela)} registros (esperado {_n(esperado)})")
        if inventario is not None and inventario.get(tabela) != esperado:
            problemas.append(f"{tabela}: inventário informa {inventario.get(tabela)} (esperado {_n(esperado)})")
    total_dimensoes = sum(len(df) for df in dims.values())
    if total_dimensoes != config.ESPERADO_TOTAL_DIMENSOES:
        problemas.append(
            f"dimensões somam {_n(total_dimensoes)} (esperado {_n(config.ESPERADO_TOTAL_DIMENSOES)})"
        )
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        f"fato {_n(len(fato))}; 7 dimensões somam {_n(total_dimensoes)}; iguais ao Inventario_Tabelas.csv",
    )


# 3 ----------------------------------------------------------------------------------

def _conferir_chaves_primarias(dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "Chaves primárias únicas"
    problemas = []
    for tabela, chave in config.CHAVES_DIMENSOES.items():
        if tabela not in dims:
            problemas.append(f"{tabela}: dimensão ausente")
            continue
        repetidas = int(dims[tabela][chave].duplicated().sum())
        if repetidas:
            problemas.append(f"{tabela}.{chave}: {_n(repetidas)} repetida(s)")
    repetidos = int(fato["id_registro"].duplicated().sum())
    if repetidos:
        problemas.append(f"{config.NOME_FATO}.id_registro: {_n(repetidos)} repetido(s)")
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(nome, True, "7 dimensões e id_registro da fato sem repetição")


# 4 ----------------------------------------------------------------------------------

def _conferir_chaves_estrangeiras(dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "FK da fato existe na dimensão"
    partes, ok = [], True
    for fk, (tabela, chave) in config.FKS_FATO.items():
        if tabela not in dims:
            partes.append(f"{fk}: {tabela} ausente")
            ok = False
            continue
        orfas = fato.loc[~fato[fk].isin(set(dims[tabela][chave])), fk]
        if len(orfas):
            ok = False
            partes.append(f"{fk}={_n(len(orfas))} (ex.: {_exemplos(orfas.fillna('vazio'))})")
        else:
            partes.append(f"{fk}=0")
    return Conferencia(nome, ok, "órfãs por chave: " + "; ".join(partes))


# 5 ----------------------------------------------------------------------------------

def _conferir_granularidade(fato: pd.DataFrame) -> Conferencia:
    nome = "Granularidade sem repetição"
    repetidas = int(fato.duplicated(subset=config.GRAO).sum())
    if repetidas:
        return Conferencia(nome, False, f"{_n(repetidas)} linha(s) repetida(s) na combinação das 7 colunas do grão")
    return Conferencia(nome, True, f"{_n(len(fato))} linhas, cada uma com combinação única de data, campanha, canal, peça, região, segmento e evento")


# 6 ----------------------------------------------------------------------------------

def _contar_ausentes(df: pd.DataFrame) -> dict[str, int]:
    """Colunas com valor ausente: NaN ou, nas colunas de texto, campo vazio/em branco."""
    resultado = {}
    for coluna in df.columns:
        serie = df[coluna]
        ausente = serie.isna()
        if not pd.api.types.is_numeric_dtype(serie):
            ausente = ausente | serie.fillna("").astype(str).str.strip().eq("")
        if ausente.any():
            resultado[coluna] = int(ausente.sum())
    return resultado


def _conferir_ausentes_e_negativos(dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "Sem ausentes e sem negativos"
    problemas = []
    for tabela, df in {config.NOME_FATO: fato, **dims}.items():
        for coluna, n in _contar_ausentes(df).items():
            problemas.append(f"ausente em {tabela}.{coluna}: {_n(n)}")
    negativos = (fato[config.MEDIDAS] < 0).sum()
    for coluna, n in negativos[negativos > 0].items():
        problemas.append(f"negativo em {coluna}: {_n(n)}")
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        f"nenhum valor ausente na fato nem nas dimensões; nenhuma das {len(config.MEDIDAS)} medidas é negativa",
    )


# 7 ----------------------------------------------------------------------------------

_TOLERANCIA_TEXTO = str(config.TOLERANCIA).replace(".", ",")

def _conferir_receita_liquida(fato: pd.DataFrame) -> Conferencia:
    nome = "Receita líquida = bruta - descontos"
    diferenca = (fato["receita_liquida"] - (fato["receita_bruta"] - fato["descontos"])).abs()
    divergentes = fato.loc[~(diferenca <= config.TOLERANCIA), "id_registro"]
    if len(divergentes):
        return Conferencia(
            nome, False,
            f"{_n(len(divergentes))} linha(s) com diferença acima de R$ {_TOLERANCIA_TEXTO} (ex.: {_exemplos(divergentes)})",
        )
    return Conferencia(
        nome, True, f"todas as {_n(len(fato))} linhas dentro da tolerância de R$ {_TOLERANCIA_TEXTO}"
    )


# 8 ----------------------------------------------------------------------------------

def _conferir_funil(fato: pd.DataFrame) -> Conferencia:
    nome = "Funil consistente"
    direto = fato["id_canal"] == config.ID_CANAL_DIRETO
    violacoes = {
        "checkouts > sessões": ~(fato["checkouts_iniciados"] <= fato["sessoes"]),
        "pedidos > checkouts": ~(fato["pedidos_confirmados"] <= fato["checkouts_iniciados"]),
        "ingressos < pedidos": ~(fato["ingressos_vendidos"] >= fato["pedidos_confirmados"]),
        "cliques > impressões": ~(fato["cliques"] <= fato["impressoes"]),
        f"Direto ({config.ID_CANAL_DIRETO}) com impressões ou cliques": direto
        & ~((fato["impressoes"] == 0) & (fato["cliques"] == 0)),
    }
    problemas = [f"{regra}: {_n(m.sum())} linha(s)" for regra, m in violacoes.items() if m.any()]
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        "checkouts ≤ sessões; pedidos ≤ checkouts; ingressos ≥ pedidos; cliques ≤ impressões; "
        f"Direto ({config.ID_CANAL_DIRETO}) sem impressões nem cliques",
    )


# 9 ----------------------------------------------------------------------------------

def _conferir_interacoes(fato: pd.DataFrame, inter: pd.DataFrame) -> Conferencia:
    nome = "Interações = mensagens do TXT"
    soma = int(fato["quantidade_interacoes"].sum())
    linhas = len(inter)
    declarado = fato.groupby("id_registro")["quantidade_interacoes"].sum().rename("declarado")
    em_texto = inter.groupby("id_registro").size().rename("texto")
    comparacao = pd.concat([declarado, em_texto], axis=1).fillna(0)
    divergentes = comparacao[comparacao["declarado"] != comparacao["texto"]]
    problemas = []
    if soma != config.ESPERADO_INTERACOES:
        problemas.append(f"soma de quantidade_interacoes = {_n(soma)} (esperado {_n(config.ESPERADO_INTERACOES)})")
    if linhas != config.ESPERADO_INTERACOES:
        problemas.append(f"TXT tem {_n(linhas)} linhas (esperado {_n(config.ESPERADO_INTERACOES)})")
    if soma != linhas:
        problemas.append(f"soma ({_n(soma)}) difere das linhas do TXT ({_n(linhas)})")
    if len(divergentes):
        problemas.append(
            f"{_n(len(divergentes))} id_registro com contagem diferente (ex.: {_exemplos(divergentes.index)})"
        )
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        f"soma de quantidade_interacoes = {_n(soma)} = linhas do TXT; "
        f"contagem por id_registro igual em {_n(len(comparacao))} registros",
    )


# 10 ---------------------------------------------------------------------------------

_METRICAS_POR_CANAL = {  # chave de ESPERADO_CANAIS -> coluna da fato
    "investimento": "investimento",
    "cliques": "cliques",
    "pedidos": "pedidos_confirmados",
    "receita_liquida": "receita_liquida",
}


def _conferir_totais_por_canal(dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "Totais por canal = relatório"
    # drop_duplicates: uma PK repetida em Dim_Canal reprova a conferência 3, não derruba esta.
    nomes = dims["Dim_Canal"].drop_duplicates("id_canal").set_index("id_canal")["nome_canal"]
    totais = (
        fato.assign(nome_canal=fato["id_canal"].map(nomes))
        .groupby("nome_canal")[list(_METRICAS_POR_CANAL.values())]
        .sum()
    )
    problemas = []
    for canal, esperado in config.ESPERADO_CANAIS.items():
        if canal not in totais.index:
            problemas.append(f"{canal}: sem linhas na fato")
            continue
        for chave, coluna in _METRICAS_POR_CANAL.items():
            obtido = totais.loc[canal, coluna]
            if abs(obtido - esperado[chave]) > config.TOLERANCIA:
                problemas.append(f"{canal} {chave}: {obtido:.2f} (esperado {esperado[chave]:.2f})")
    for canal in totais.index.difference(list(config.ESPERADO_CANAIS)):
        problemas.append(f"{canal}: canal fora do relatório")
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        f"{len(config.ESPERADO_CANAIS)} canais: investimento, cliques, pedidos e receita líquida iguais ao relatório",
    )


# 11 ---------------------------------------------------------------------------------

def _conferir_datas(dims: dict, fato: pd.DataFrame) -> Conferencia:
    nome = "Datas no período e no calendário"
    datas = pd.to_datetime(fato["data"], format="%Y-%m-%d", errors="coerce")
    invalidas = datas.isna()
    fora_do_periodo = (datas < pd.Timestamp(config.DATA_INICIO_FATO)) | (datas > pd.Timestamp(config.DATA_FIM_FATO))
    fora_do_calendario = ~fato["data"].isin(set(dims["Dim_Calendario"]["data"]))
    problemas = []
    if invalidas.any():
        problemas.append(f"{_n(invalidas.sum())} data(s) inválida(s) (ex.: {_exemplos(fato.loc[invalidas, 'data'].fillna('vazio'))})")
    if fora_do_periodo.any():
        problemas.append(f"{_n(fora_do_periodo.sum())} data(s) fora do período (ex.: {_exemplos(fato.loc[fora_do_periodo, 'data'])})")
    if fora_do_calendario.any():
        problemas.append(f"{_n(fora_do_calendario.sum())} data(s) ausente(s) do calendário (ex.: {_exemplos(fato.loc[fora_do_calendario, 'data'].fillna('vazio'))})")
    if problemas:
        return Conferencia(nome, False, _fim_de_lista(problemas))
    return Conferencia(
        nome, True,
        f"{datas.min():%Y-%m-%d} a {datas.max():%Y-%m-%d}, dentro de {config.DATA_INICIO_FATO} a {config.DATA_FIM_FATO} e todas no calendário",
    )


def conferir_tudo(pasta: Path, dims: dict, fato: pd.DataFrame, inter: pd.DataFrame) -> list[Conferencia]:
    """Executa as 11 conferências, na ordem da especificação."""
    pasta = Path(pasta)
    return [
        _conferir_sha256(pasta),
        _conferir_contagens(pasta, dims, fato),
        _conferir_chaves_primarias(dims, fato),
        _conferir_chaves_estrangeiras(dims, fato),
        _conferir_granularidade(fato),
        _conferir_ausentes_e_negativos(dims, fato),
        _conferir_receita_liquida(fato),
        _conferir_funil(fato),
        _conferir_interacoes(fato, inter),
        _conferir_totais_por_canal(dims, fato),
        _conferir_datas(dims, fato),
    ]
