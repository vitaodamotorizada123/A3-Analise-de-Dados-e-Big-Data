"""Regras de classificação das mensagens do público em (tema, tipo).

Cada regra é um trecho de texto (sem diferenciar maiúsculas); vale a primeira que aparecer.
"""

# Coluna da fato que conta as dúvidas de cada tema (a ordem define a ordem das colunas).
COLUNA_DUVIDA: dict[str, str] = {
    "Preço e condições": "duv_preco",
    "Deslocamento": "duv_deslocamento",
    "Acessibilidade": "duv_acessibilidade",
    "Programação": "duv_programacao",
    "Compra e site": "duv_compra_site",
    "Atenção e marca": "duv_atencao_marca",
}

# (trecho do texto, tema, tipo)
REGRAS = [
 ("O valor mostrado inclui todas as taxas", "Preço e condições", "dúvida"),
 ("desconto vale para todas as oficinas", "Preço e condições", "dúvida"),
 ("mudança de preço entre os lotes", "Preço e condições", "dúvida"),
 ("entender o ingresso social", "Preço e condições", "dúvida"),
 ("condição de desconto ficou clara", "Preço e condições", "positivo"),
 ("endereço no anúncio é o mesmo", "Deslocamento", "dúvida"),
 ("estacionamento perto do evento", "Deslocamento", "dúvida"),
 ("planejar o deslocamento", "Deslocamento", "dúvida"),
 ("transporte público", "Deslocamento", "dúvida"),
 ("orientação de trajeto ajudou", "Deslocamento", "positivo"),
 ("como funciona o espaço reservado", "Acessibilidade", "dúvida"),
 ("acessibilidade estivessem mais visíveis", "Acessibilidade", "dúvida"),
 ("rota acessível", "Acessibilidade", "dúvida"),
 ("recursos de acessibilidade", "Acessibilidade", "dúvida"),
 ("participação e acessibilidade foi útil", "Acessibilidade", "positivo"),
 ("Cinema e música acontecem no mesmo horário", "Programação", "dúvida"),
 ("horário das oficinas", "Programação", "dúvida"),
 ("programação combina comigo", "Programação", "dúvida"),
 ("mais artistas locais", "Programação", "sugestão"),
 ("Gostei dos artistas anunciados", "Programação", "positivo"),
 ("combinando com amigos", "Programação", "positivo"),
 ("dúvida sobre o botão de ingressos", "Compra e site", "dúvida"),
 ("página demorou para abrir", "Compra e site", "dúvida"),
 ("voltei depois para terminar", "Compra e site", "dúvida"),
 ("ingresso para mais de uma pessoa", "Compra e site", "dúvida"),
 ("concluir a compra com facilidade", "Compra e site", "positivo"),
 ("ainda não entendi a proposta", "Atenção e marca", "dúvida"),
 ("fui procurar mais informações", "Atenção e marca", "dúvida"),
 ("conheci o festival", "Atenção e marca", "positivo"),
 ("conectar culturas chamou minha atenção", "Atenção e marca", "positivo"),
]


def classificar(txt: str) -> tuple[str, str]:
    """Devolve (tema, tipo) da mensagem; ("Não classificado", "não classificado") se nenhuma regra servir."""
    for chave, tema, tipo in REGRAS:
        if chave.lower() in txt.lower():
            return tema, tipo
    return "Não classificado", "não classificado"
