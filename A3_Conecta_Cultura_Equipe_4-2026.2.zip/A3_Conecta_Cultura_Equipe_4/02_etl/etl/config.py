"""Constantes do ETL: origem dos dados, valores esperados e mapa de chaves."""
import os
from pathlib import Path

# Pasta original do caso (somente leitura). Por padrão fica em `dados_originais/Conecta_Cultura_Estrela_100mil`, na raiz
# do projeto (a pasta que contém `etl/`). Para ler de outro lugar, passe --origem ao ETL ou defina CONECTA_ORIGEM.
RAIZ = Path(__file__).resolve().parent.parent
ORIGEM = Path(os.environ.get(
    "CONECTA_ORIGEM", RAIZ / "dados_originais" / "Conecta_Cultura_Estrela_100mil"
))

# Caminhos relativos à raiz do pacote do caso.
PASTA_DIMENSOES = "01_dimensoes"
ARQUIVO_FATO = "02_fatos/Fato_Desempenho_Campanha.csv"
ARQUIVO_INTERACOES = "03_textos/Interacoes_Publico.txt"
ARQUIVO_MANIFESTO = "MANIFESTO_ARQUIVOS.csv"
ARQUIVO_INVENTARIO = "04_documentacao/Inventario_Tabelas.csv"
ARQUIVO_EXTRATO = "05_exercicio_ETL/Extrato_Para_Limpeza.csv"  # exercício isolado, nunca vai para a fato

NOME_FATO = "Fato_Desempenho_Campanha"

# Inventario_Tabelas.csv: registros esperados (fato + 7 dimensões, ordem do inventário).
ESPERADO_CONTAGENS: dict[str, int] = {
    "Dim_Calendario": 852,
    "Dim_Regiao": 12,
    "Dim_Canal": 8,
    "Dim_Segmento_Publico": 6,
    "Dim_Evento": 12,
    "Dim_Campanha": 24,
    "Dim_Peca_Publicitaria": 120,
    NOME_FATO: 100000,
}
ESPERADO_TOTAL_DIMENSOES = 1034
ESPERADO_INTERACOES = 3000
LINHAS_EXERCICIO = 100  # o extrato do exercício reapresenta as 100 primeiras linhas da fato (+ 5 duplicadas)

# Chave primária de cada dimensão (mesma ordem de ESPERADO_CONTAGENS).
CHAVES_DIMENSOES: dict[str, str] = {
    "Dim_Calendario": "data",
    "Dim_Regiao": "id_regiao",
    "Dim_Canal": "id_canal",
    "Dim_Segmento_Publico": "id_segmento",
    "Dim_Evento": "id_evento",
    "Dim_Campanha": "id_campanha",
    "Dim_Peca_Publicitaria": "id_peca",
}

# Chave estrangeira da fato -> (dimensão, coluna-chave). Relacionamentos.csv.
FKS_FATO: dict[str, tuple[str, str]] = {
    "data": ("Dim_Calendario", "data"),
    "id_campanha": ("Dim_Campanha", "id_campanha"),
    "id_canal": ("Dim_Canal", "id_canal"),
    "id_peca": ("Dim_Peca_Publicitaria", "id_peca"),
    "id_regiao": ("Dim_Regiao", "id_regiao"),
    "id_segmento": ("Dim_Segmento_Publico", "id_segmento"),
    "id_evento": ("Dim_Evento", "id_evento"),
}

# Granularidade da fato: uma linha por combinação destas sete colunas.
GRAO = ["data", "id_campanha", "id_canal", "id_peca", "id_regiao", "id_segmento", "id_evento"]

COLUNAS_MONETARIAS = ["investimento", "receita_bruta", "descontos", "receita_liquida"]
COLUNAS_CONTAGEM = [
    "impressoes", "cliques", "sessoes", "checkouts_iniciados",
    "pedidos_confirmados", "ingressos_vendidos", "quantidade_interacoes",
]
MEDIDAS = COLUNAS_MONETARIAS + COLUNAS_CONTAGEM

ID_CANAL_DIRETO = "CH08"  # Direto: não tem impressões nem cliques

# Período do histórico (a dimensão calendário vai até 2026-12-31).
DATA_INICIO_FATO = "2024-09-01"
DATA_FIM_FATO = "2026-08-31"

TOLERANCIA = 0.005  # em R$, para somas e diferenças de valores monetários

# Totais por canal do 02_Relatorio_Historico_e_Reuniao.pdf.
ESPERADO_CANAIS: dict[str, dict] = {
    "Instagram Ads": {"investimento": 46608.12, "cliques": 99647, "pedidos": 2767, "receita_liquida": 455439.00},
    "TikTok Ads": {"investimento": 34169.06, "cliques": 152275, "pedidos": 2366, "receita_liquida": 398561.00},
    "Google Pesquisa": {"investimento": 66582.61, "cliques": 175784, "pedidos": 10087, "receita_liquida": 1680982.00},
    "YouTube Ads": {"investimento": 16368.68, "cliques": 25128, "pedidos": 576, "receita_liquida": 93447.50},
    "Redes sociais orgânicas": {"investimento": 0.00, "cliques": 65717, "pedidos": 2429, "receita_liquida": 404107.50},
    "E-mail": {"investimento": 0.00, "cliques": 124961, "pedidos": 8224, "receita_liquida": 1381607.50},
    "Influenciadores": {"investimento": 22682.51, "cliques": 42569, "pedidos": 1321, "receita_liquida": 215367.50},
    "Direto": {"investimento": 0.00, "cliques": 0, "pedidos": 2005, "receita_liquida": 340504.50},
}
