"""Leitura dos arquivos do caso, sem alterar nenhum valor.

CSVs: UTF-8 com BOM, separador ";", ponto decimal. Colunas de texto (inclusive datas)
são lidas como `object` com `keep_default_na=False`: campo vazio vira "" e textos como
"NA" não são confundidos com ausente. Assim o resultado é o mesmo em pandas 2 e 3.
"""
import csv
from pathlib import Path

import pandas as pd

from etl import config


def ler_csv(caminho: Path) -> pd.DataFrame:
    """Lê um CSV do pacote do caso, todas as colunas como texto."""
    return pd.read_csv(
        caminho, sep=";", encoding="utf-8-sig", dtype=object, keep_default_na=False
    )


def ler_dimensoes(pasta: Path) -> dict[str, pd.DataFrame]:
    """Lê as 7 dimensões; chaves = nome da tabela (ex.: "Dim_Canal"). Todas as colunas como texto."""
    pasta = Path(pasta)
    return {
        nome: ler_csv(pasta / config.PASTA_DIMENSOES / f"{nome}.csv")
        for nome in config.CHAVES_DIMENSOES
    }


def converter_medidas(df: pd.DataFrame) -> pd.DataFrame:
    """Converte as medidas lidas como texto: valores monetários em float, contagens em int."""
    for coluna in config.MEDIDAS:
        df[coluna] = pd.to_numeric(df[coluna])  # vazio -> NaN; texto inválido -> erro
    for coluna in config.COLUNAS_CONTAGEM:
        if df[coluna].notna().all():
            df[coluna] = df[coluna].astype("int64")
    return df


def ler_fato(pasta: Path) -> pd.DataFrame:
    """Lê a fato: IDs e `data` como texto; medidas numéricas (valores em float, contagens em int)."""
    return converter_medidas(ler_csv(Path(pasta) / config.ARQUIVO_FATO))


def ler_interacoes(pasta: Path) -> pd.DataFrame:
    """Lê o TXT de mensagens (sem cabeçalho, separado por TAB, sem tratamento de aspas)."""
    return pd.read_csv(
        Path(pasta) / config.ARQUIVO_INTERACOES,
        sep="\t",
        header=None,
        names=["id_interacao", "id_registro", "mensagem"],
        encoding="utf-8-sig",
        quoting=csv.QUOTE_NONE,
        dtype=object,
        keep_default_na=False,
    )
