"""Script principal do ETL do caso Conecta Cultura (A3).

Uso: python -m etl.etl_conecta [--origem PASTA] [--destino PASTA]

Lê o pacote original do caso (somente leitura), roda as 11 conferências de integridade, acrescenta à
fato as colunas derivadas e grava em `destino` os CSVs tratados e o `log_etl.md`. As conferências que
reprovam não impedem a gravação: o log registra o resultado e `main` devolve 1.

Regras de gravação dos CSVs: UTF-8 sem BOM, separador ";", ponto decimal, fim de linha "\\n", sem índice;
datas como na fonte (AAAA-MM-DD); valores monetários com 2 casas; contagens como inteiros.
"""
import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

from etl import config, log
from etl.carregar import ler_dimensoes, ler_fato, ler_interacoes
from etl.conferencias import Conferencia, _n, conferir_tudo
from etl.exercicio import comparar_com_fonte, ler_extrato, limpar_extrato
from etl.temas import COLUNA_DUVIDA
from etl.transformar import (
    COLUNAS_MENSAGENS,
    adicionar_semanas,
    agregar_mensagens,
    classificar_interacoes,
)

DESTINO_PADRAO = Path(__file__).resolve().parent.parent / "build" / "03_dados_tratados"

ARQUIVO_FATO_TRATADA = f"{config.NOME_FATO}_tratada.csv"
ARQUIVO_INTERACOES_CLASSIFICADAS = "Interacoes_Classificadas.csv"
ARQUIVO_EXERCICIO = "Exercicio_ETL_resultado.csv"
ARQUIVO_LOG = "log_etl.md"

NOME_FATO_TRATADA = "Fato tratada gerada"
NOME_COMPARACAO_EXERCICIO = "Exercício de ETL = fonte"  # mesmo nome que exercicio.comparar_com_fonte usa

TIPOS = ["dúvida", "positivo", "sugestão"]  # ordem das colunas da tabela tema x tipo no log


def gravar_csv(df: pd.DataFrame, caminho: Path) -> None:
    """Grava `df` como CSV nas regras do projeto. Só as colunas monetárias podem ser decimais."""
    decimais = [
        coluna for coluna in df.columns
        if pd.api.types.is_float_dtype(df[coluna]) and coluna not in config.COLUNAS_MONETARIAS
    ]
    if decimais:
        raise ValueError(f"coluna(s) decimal(is) que não são monetárias em {Path(caminho).name}: {decimais}")
    df.to_csv(
        caminho, sep=";", index=False, encoding="utf-8", float_format="%.2f", lineterminator="\n"
    )


def _tabela_tema_tipo(inter_classif: pd.DataFrame) -> pd.DataFrame:
    """Contagem de mensagens por tema (linhas) e tipo (colunas), na ordem dos temas e dos tipos do projeto."""
    contagem = inter_classif.groupby(["tema", "tipo"]).size().unstack(fill_value=0)
    temas = [*COLUNA_DUVIDA, *sorted(set(contagem.index) - set(COLUNA_DUVIDA))]
    tipos = [*TIPOS, *sorted(set(contagem.columns) - set(TIPOS))]
    return contagem.reindex(index=temas, columns=tipos, fill_value=0)


def _verificar_transformacoes(
    fato: pd.DataFrame, tratada: pd.DataFrame, inter_classif: pd.DataFrame
) -> list[Conferencia]:
    """Confere o que as transformações prometem: nada original muda e as mensagens fecham com a fato."""
    originais = list(fato.columns)
    inalterada = list(tratada.columns[: len(originais)]) == originais and tratada[originais].equals(fato)
    verificacoes = [
        Conferencia(
            "Valores originais inalterados",
            inalterada,
            f"as {len(originais)} colunas originais e as {_n(len(fato))} linhas iguais às da fonte, "
            "na mesma ordem"
            if inalterada
            else "colunas, linhas ou valores originais da fato mudaram",
        )
    ]

    n_colunas = len(COLUNAS_MENSAGENS)
    divergentes = int((tratada[COLUNAS_MENSAGENS].sum(axis=1) != tratada["quantidade_interacoes"]).sum())
    verificacoes.append(Conferencia(
        "Mensagens por linha = quantidade_interacoes",
        divergentes == 0,
        f"soma das {n_colunas} colunas igual a quantidade_interacoes em todas as {_n(len(tratada))} linhas"
        if divergentes == 0
        else f"{_n(divergentes)} linha(s) em que a soma das {n_colunas} colunas difere de quantidade_interacoes",
    ))

    tema_invalido = ~inter_classif["tema"].isin(set(COLUNA_DUVIDA))
    sem_classe = int((tema_invalido | ~inter_classif["tipo"].isin(set(TIPOS))).sum())
    verificacoes.append(Conferencia(
        "Mensagens classificadas",
        sem_classe == 0,
        f"nenhuma das {_n(len(inter_classif))} mensagens ficou sem tema ou tipo"
        if sem_classe == 0
        else f"{_n(sem_classe)} mensagem(ns) sem tema ou tipo",
    ))
    return verificacoes


def _imprimir_resumo(conferencias, verificacoes, comparacao, origem, destino, arquivos) -> None:
    aprovadas = sum(c.ok for c in conferencias)
    print("ETL Conecta Cultura")
    print(f"  origem:  {origem}")
    print(f"  destino: {destino}")
    print(f"  conferências: {aprovadas}/{len(conferencias)} aprovadas")
    print(f"  transformações: {'OK' if all(v.ok for v in verificacoes) else 'FALHOU'}")
    print(f"  exercício de ETL: {'OK' if comparacao.ok else 'FALHOU'}")
    print(f"  arquivos gravados: {len(arquivos)}")
    for c in conferencias:
        if not c.ok:
            print(f"  REPROVADO: {c.nome} - {c.detalhe}")
    for v in [*verificacoes, comparacao]:
        if not v.ok:
            print(f"  FALHOU: {v.nome} - {v.detalhe}")


def _numa_linha(erro: Exception) -> str:
    """Mensagem do erro numa linha só (o pandas devolve mensagens com várias linhas)."""
    return " ".join(str(erro).split())


def _transformar_fato(fato, dims, inter_classif):
    """Fato tratada e suas verificações. Se uma transformação levanta ValueError (as mesmas causas das
    conferências 3, 4 e 9), devolve (None, [falha]) para o log registrar o erro em vez de abortar."""
    try:
        tratada = agregar_mensagens(adicionar_semanas(fato, dims["Dim_Evento"]), inter_classif)
    except ValueError as erro:
        return None, [Conferencia(
            NOME_FATO_TRATADA, False, f"não gerada: {_numa_linha(erro)}; {ARQUIVO_FATO_TRATADA} não foi gravado"
        )]
    return tratada, _verificar_transformacoes(fato, tratada, inter_classif)


def _executar_exercicio(origem, fato, dims):
    """Limpeza do extrato e comparação com a fonte: (extrato, limpo, exemplos, comparação).
    Se a leitura ou a limpeza levanta ValueError, `limpo` é None e a comparação registra a falha."""
    extrato = limpo = None
    try:
        extrato = ler_extrato(origem)
        limpo, exemplos = limpar_extrato(extrato, dims["Dim_Canal"])
    except ValueError as erro:
        comparacao = Conferencia(
            NOME_COMPARACAO_EXERCICIO, False,
            f"exercício não concluído: {_numa_linha(erro)}; {ARQUIVO_EXERCICIO} não foi gravado",
        )
        return extrato, None, [], comparacao
    return extrato, limpo, exemplos, comparar_com_fonte(limpo, fato, dims["Dim_Canal"])


def main(origem: Path, destino: Path) -> int:
    """Roda o ETL de `origem` para `destino` (criado se não existir). Devolve 0 se tudo passou, 1 se não.

    Conferências reprovadas não impedem a gravação. Se a fato tratada ou o resultado do exercício não
    puderam ser gerados (ValueError), o arquivo não é gravado, uma versão antiga em `destino` é apagada
    para não passar por resultado desta execução, e o log registra a falha.
    """
    origem, destino = Path(origem), Path(destino)
    executado_em = datetime.now()

    dims = ler_dimensoes(origem)
    fato = ler_fato(origem)
    inter = ler_interacoes(origem)
    conferencias = conferir_tudo(origem, dims, fato, inter)

    inter_classif = classificar_interacoes(inter)
    tratada, verificacoes = _transformar_fato(fato, dims, inter_classif)
    extrato, limpo, exemplos, comparacao = _executar_exercicio(origem, fato, dims)

    destino.mkdir(parents=True, exist_ok=True)
    tabelas = {
        **{f"{nome}.csv": df for nome, df in dims.items()},
        ARQUIVO_FATO_TRATADA: tratada,
        ARQUIVO_INTERACOES_CLASSIFICADAS: inter_classif,
        ARQUIVO_EXERCICIO: limpo,
    }
    for nome_arquivo, df in tabelas.items():
        if df is None:
            (destino / nome_arquivo).unlink(missing_ok=True)
        else:
            gravar_csv(df, destino / nome_arquivo)

    resumo = {
        "origem": origem.resolve(),
        "destino": destino.resolve(),
        "executado_em": executado_em,
        "linhas_antes": len(fato),
        "linhas_depois": None if tratada is None else len(tratada),
        "colunas_mensagens": None if tratada is None else {c: int(tratada[c].sum()) for c in COLUNAS_MENSAGENS},
        "tema_tipo": _tabela_tema_tipo(inter_classif),
        "verificacoes": verificacoes,
        "extrato_linhas_antes": None if extrato is None else len(extrato),
        "extrato_linhas_depois": None if limpo is None else len(limpo),
        "comparacao_exercicio": comparacao,
    }
    log.escrever_log(destino / ARQUIVO_LOG, conferencias, exemplos, resumo)

    gravados = [nome for nome, df in tabelas.items() if df is not None] + [ARQUIVO_LOG]
    _imprimir_resumo(conferencias, verificacoes, comparacao, resumo["origem"], resumo["destino"], gravados)
    tudo_ok = all(c.ok for c in conferencias) and all(v.ok for v in verificacoes) and comparacao.ok
    return 0 if tudo_ok else 1


def ler_argumentos(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="python -m etl.etl_conecta",
        description="ETL do caso Conecta Cultura: confere, trata e grava os CSVs e o log_etl.md.",
    )
    parser.add_argument(
        "--origem", type=Path, default=config.ORIGEM,
        help="pasta do pacote original do caso (padrão: CONECTA_ORIGEM ou %(default)s)",
    )
    parser.add_argument(
        "--destino", type=Path, default=DESTINO_PADRAO,
        help="pasta de saída, criada se não existir (padrão: %(default)s)",
    )
    return parser.parse_args(argv)


def arquivo_do_caso_ausente(origem: Path) -> str | None:
    """Primeiro arquivo do caso, entre os que o ETL lê, que falta em `origem` (None se estão todos).

    O manifesto vem primeiro: uma pasta que não é a do caso acusa a falta dele.
    """
    esperados = [
        config.ARQUIVO_MANIFESTO, config.ARQUIVO_INVENTARIO, config.ARQUIVO_FATO, config.ARQUIVO_INTERACOES,
        config.ARQUIVO_EXTRATO, *(f"{config.PASTA_DIMENSOES}/{nome}.csv" for nome in config.CHAVES_DIMENSOES),
    ]
    return next((nome for nome in esperados if not (Path(origem) / nome).is_file()), None)


def cli(argv: list[str] | None = None) -> int:
    argumentos = ler_argumentos(argv)
    ausente = arquivo_do_caso_ausente(argumentos.origem)
    if ausente:  # pasta errada: uma linha clara em vez de um traceback do pandas
        print(f"ERRO: a pasta de origem não contém os arquivos do caso ({ausente})", file=sys.stderr)
        return 1
    return main(argumentos.origem, argumentos.destino)


if __name__ == "__main__":
    sys.exit(cli())
