# Log do ETL - Conecta Cultura (A3)

- **Origem:** pasta `Conecta_Cultura_Estrela_100mil`
- **Destino:** pasta `03_dados_tratados`
- **Resultado geral:** 11 de 11 conferências aprovadas; transformações OK; exercício de ETL OK

## Conferências de integridade

| nº | Conferência | Resultado | Detalhe |
| --- | --- | --- | --- |
| 1 | SHA-256 = manifesto | APROVADO | 21 arquivos listados no manifesto, todos com o mesmo SHA-256 |
| 2 | Contagens = inventário | APROVADO | fato 100.000; 7 dimensões somam 1.034; iguais ao Inventario_Tabelas.csv |
| 3 | Chaves primárias únicas | APROVADO | 7 dimensões e id_registro da fato sem repetição |
| 4 | FK da fato existe na dimensão | APROVADO | órfãs por chave: data=0; id_campanha=0; id_canal=0; id_peca=0; id_regiao=0; id_segmento=0; id_evento=0 |
| 5 | Granularidade sem repetição | APROVADO | 100.000 linhas, cada uma com combinação única de data, campanha, canal, peça, região, segmento e evento |
| 6 | Sem ausentes e sem negativos | APROVADO | nenhum valor ausente na fato nem nas dimensões; nenhuma das 11 medidas é negativa |
| 7 | Receita líquida = bruta - descontos | APROVADO | todas as 100.000 linhas dentro da tolerância de R$ 0,005 |
| 8 | Funil consistente | APROVADO | checkouts ≤ sessões; pedidos ≤ checkouts; ingressos ≥ pedidos; cliques ≤ impressões; Direto (CH08) sem impressões nem cliques |
| 9 | Interações = mensagens do TXT | APROVADO | soma de quantidade_interacoes = 3.000 = linhas do TXT; contagem por id_registro igual em 100.000 registros |
| 10 | Totais por canal = relatório | APROVADO | 8 canais: investimento, cliques, pedidos e receita líquida iguais ao relatório |
| 11 | Datas no período e no calendário | APROVADO | 2024-09-01 a 2026-08-26, dentro de 2024-09-01 a 2026-08-31 e todas no calendário |

## Transformações

A fato recebe 10 colunas novas ao final; as colunas, as linhas e os valores originais ficam como estão.

### Semanas até o evento

| Coluna | Regra |
| --- | --- |
| dias_ate_evento | data do evento (Dim_Evento) menos `data`, em dias |
| semana_antes_evento | teto de `dias_ate_evento` / 7 (0 = dia do evento) |

### Mensagens do público por linha da fato (contagem por `id_registro`; 0 quando não há mensagem)

| Coluna | Regra | Mensagens |
| --- | --- | ---: |
| duv_preco | mensagens de tipo dúvida no tema Preço e condições | 565 |
| duv_deslocamento | mensagens de tipo dúvida no tema Deslocamento | 406 |
| duv_acessibilidade | mensagens de tipo dúvida no tema Acessibilidade | 254 |
| duv_programacao | mensagens de tipo dúvida no tema Programação | 380 |
| duv_compra_site | mensagens de tipo dúvida no tema Compra e site | 302 |
| duv_atencao_marca | mensagens de tipo dúvida no tema Atenção e marca | 156 |
| msg_positivas | mensagens de tipo positivo, de qualquer tema | 782 |
| msg_sugestoes | mensagens de tipo sugestão, de qualquer tema | 155 |
| **Soma** |  | 3.000 |

- Linhas da fato antes e depois: 100.000 = 100.000
- Soma das 8 colunas de mensagens = 3.000
- OK: Valores originais inalterados - as 19 colunas originais e as 100.000 linhas iguais às da fonte, na mesma ordem
- OK: Mensagens por linha = quantidade_interacoes - soma das 8 colunas igual a quantidade_interacoes em todas as 100.000 linhas
- OK: Mensagens classificadas - nenhuma das 3.000 mensagens ficou sem tema ou tipo

### Classificação das mensagens

Amostra de 150 mensagens (semente 20261031): 150/150 classificações conferidas manualmente contra as regras. O tipo "dúvida" reúne dúvidas, barreiras e pedidos de informação.

Mensagens por tema e tipo:

| Tema | dúvida | positivo | sugestão | Total |
| --- | ---: | ---: | ---: | ---: |
| Preço e condições | 565 | 121 | 0 | 686 |
| Deslocamento | 406 | 114 | 0 | 520 |
| Acessibilidade | 254 | 76 | 0 | 330 |
| Programação | 380 | 257 | 155 | 792 |
| Compra e site | 302 | 77 | 0 | 379 |
| Atenção e marca | 156 | 137 | 0 | 293 |
| Total | 2.063 | 782 | 155 | 3.000 |

## Exercício de ETL

Cópia de treinamento isolada (`Extrato_Para_Limpeza.csv`): não é anexada à fato nem ao modelo.

- Linhas: 105 no extrato, 100 depois da limpeza
- Comparação com as 100 primeiras linhas da fato: OK - 100 linhas únicas; os 19 campos da fato iguais às 100 primeiras linhas (valores monetários com tolerância de R$ 0,005); canal_informado igual ao nome do Dim_Canal em todas
- Regras, nesta ordem:
  1. `espaços/caixa`: tira os espaços das pontas e usa a caixa do nome oficial do canal (Dim_Canal)
  2. `vazio recuperado pelo id_canal`: canal vazio recebe o nome do Dim_Canal para o `id_canal` da própria linha
  3. `duplicata removida`: linha repetida pelo `id_registro` é removida; fica a primeira

Antes e depois de cada alteração (entre aspas, para mostrar vazios e espaços):

| id_registro | antes | depois | regra |
| --- | --- | --- | --- |
| FT000003 | `" youtube ads "` | `"YouTube Ads"` | espaços/caixa |
| FT000009 | `" direto "` | `"Direto"` | espaços/caixa |
| FT000018 | `" youtube ads "` | `"YouTube Ads"` | espaços/caixa |
| FT000030 | `" e-mail "` | `"E-mail"` | espaços/caixa |
| FT000042 | `" redes sociais orgânicas "` | `"Redes sociais orgânicas"` | espaços/caixa |
| FT000054 | `" google pesquisa "` | `"Google Pesquisa"` | espaços/caixa |
| FT000008 | `""` | `"E-mail"` | vazio recuperado pelo id_canal |
| FT000032 | `""` | `"Google Pesquisa"` | vazio recuperado pelo id_canal |
| FT000065 | `""` | `"Instagram Ads"` | vazio recuperado pelo id_canal |
| FT000083 | `""` | `"Google Pesquisa"` | vazio recuperado pelo id_canal |
| FT000002 | `"linha 101 do extrato (repete a linha 2)"` | `"removida; fica a linha 2"` | duplicata removida |
| FT000016 | `"linha 102 do extrato (repete a linha 16)"` | `"removida; fica a linha 16"` | duplicata removida |
| FT000036 | `"linha 103 do extrato (repete a linha 36)"` | `"removida; fica a linha 36"` | duplicata removida |
| FT000068 | `"linha 104 do extrato (repete a linha 68)"` | `"removida; fica a linha 68"` | duplicata removida |
| FT000091 | `"linha 105 do extrato (repete a linha 91)"` | `"removida; fica a linha 91"` | duplicata removida |
