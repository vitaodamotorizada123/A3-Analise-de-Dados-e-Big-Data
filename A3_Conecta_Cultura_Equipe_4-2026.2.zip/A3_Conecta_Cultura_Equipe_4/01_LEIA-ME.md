# Do clique ao ingresso no Festival Conecta

**Equipe 4** · Análise de Dados e Big Data, A3 2026/2 · UniBH Professor Alexandre de Cássio Rodrigues

Nesta pasta estão os entregáveis da nossa A3 sobre o caso Conecta Cultura: o tratamento dos dados (ETL) e o seu registro, o modelo estrela com o painel no Power BI, o documento técnico, o resumo expandido, o roteiro do vídeo e as figuras da análise.

&nbsp;

Eduardo de Oliveira Rodrigues (representante)

Thomas Sheldon Freire Padley&nbsp;

Samuel Andrade Resende&nbsp;

Vitor Hugo Xavier Teodoro&nbsp;&nbsp;

Victor Emanuel Maksud Carneiro&nbsp;

Daniel Amorim Monteiro Barbosa&nbsp;

Pedro Henrique Gripp dos Santos Castro&nbsp;

Mateus Henrique Ferreira Braga&nbsp;

&nbsp;

&nbsp;

[https\://github.com/vitaodamotorizada123/A3-Analise-de-Dados-e-Big-Data](https://github.com/vitaodamotorizada123/A3-Analise-de-Dados-e-Big-Data)

&nbsp;

Os dados do caso são sintéticos. Os arquivos originais do caso ficam intocados no .zip do caso: tudo o que está aqui foi gerado sem alterá-los.

### As 5 páginas do painel e as 5 visualizações obrigatórias

| Página | Visualização obrigatória |
| :---- | :---- |
| Visão geral | V1 Evolução temporal e V5 Jornada até a compra |
| Mídia | V2 Comparação de canais |
| Comercial | V4 Distribuição por evento |
| Comunicação | V3 Comparação de peças |
| Conferência | tabela que compara os totais do painel com os esperados (não é uma das cinco visualizações) |

## Como abrir o painel

1. Abra o Power BI Desktop, versão de setembro de 2026 ou mais recente.  
2. Abra `04_powerbi\Conecta_Cultura.pbip`. O painel já vem configurado para a pasta `C:\Users\Usuario\Downloads\A3_Conecta_Cultura\`: se o pacote estiver lá, não há nada a ajustar.  
3. Se a pasta estiver em outro lugar, vá em **Transformar dados › Editar parâmetros** e preencha **PastaDados** com o caminho completo da pasta `03_dados_tratados`, terminando com `\` (por exemplo, `D:\Trabalhos\A3_Conecta_Cultura\03_dados_tratados\`).  
4. Clique em **Atualizar**.  
5. Na página **Conferência** devem aparecer 7 linhas com o status **OK**.

## Como refazer o processamento

Precisamos do Python 3.12 ou mais recente e das bibliotecas pandas, matplotlib e numpy (as versões mínimas, que são as que usamos, estão em `02_etl/requisitos.txt`). Abra um terminal dentro da pasta `02_etl` e instale as bibliotecas:

```
pip install -r requisitos.txt
```

Ainda dentro de `02_etl`, rode, nesta ordem:

```
python -m etl.etl_conecta --origem "<pasta do caso descompactada>\Conecta_Cultura_Estrela_100mil" --destino ..\03_dados_tratados
python -m analise.resultados --dados ..\03_dados_tratados --saida resultados.json
python -m analise.figuras --resultados resultados.json --saida ..\05_textos\figuras
```

- O primeiro comando lê o caso original (sem alterá-lo), roda as 11 conferências, grava os CSVs tratados e o `log_etl.md` em `03_dados_tratados`. Ao final ele escreve `11/11 aprovadas` quando tudo confere.  
- O segundo calcula todos os números da análise e os grava em `resultados.json`, na própria pasta `02_etl`. Os números dos textos saem desse arquivo.  
- O terceiro redesenha as figuras em `05_textos\figuras`.  
- Depois de refazer o ETL, clique em **Atualizar** no Power BI para ler os CSVs novos.

## Totais de conferência

São os mesmos indicadores, na mesma ordem, da página Conferência do painel:

| Indicador | Valor esperado |
| :---- | :---- |
| Registros na fato | 100.000 |
| Investimento (R\$) | 186.410,98 |
| Pedidos | 29.775 |
| Ingressos | 39.671 |
| Receita líquida (R\$) | 4.970.016,50 |
| Mensagens | 3.000 |
| Investimento Google Pesquisa (R\$) | 66.582,61 |

## Conferências do ETL

11 de 11 conferências aprovadas, registradas em `03_dados_tratados/log_etl.md`.